# raw_engine_v1 package

First-working-version raw primitive engine, split into a small CMake project.

Structure:
- `include/raw_engine/raw_engine.hpp`
- `src/raw_core.cpp`
- `src/raw_validators.cpp`
- `src/raw_primitives.cpp`
- `src/raw_planner.cpp`
- `tests/raw_engine_cases.cpp`
- `tests/exhaustive_generator.cpp`
- `tests/exhaustive_cases.cpp`
- `tests/metamorphic_cases.cpp`
- `tests/split_choice_oracle.cpp`
- `tests/split_choice_cases.cpp`
- `tests/raw_engine_main.cpp`

Primary target:
- `raw_engine_tests`

CLI examples:
```bash
./raw_engine_tests --case micro
./raw_engine_tests --case fuzz --seed 44001 --iters 1
./raw_engine_tests --case planner --seed 123 --iters 1000
./raw_engine_tests --case fuzz_matrix --iters 20
./raw_engine_tests --case isolate_fuzz --seed 710001 --iters 100
./raw_engine_tests --case split_join_fuzz --seed 715001 --iters 100
./raw_engine_tests --case planner_mixed_fuzz --seed 717001 --iters 100 --step-budget 200000
./raw_engine_tests --case regression_44001
./raw_engine_tests --case regression_isolate_split_no_sep
./raw_engine_tests --case repro --repro-file counterexamples/reduced_isolate_split_seed3736675150.txt
./raw_engine_tests --case planner_targeted_mixed_smoke
./raw_engine_tests --case planner_coverage_smoke
./raw_engine_tests --case planner_random_coverage_smoke
./raw_engine_tests --case planner_weighted_coverage_smoke
./raw_engine_tests --case planner_join_ready_smoke
./raw_engine_tests --case planner_integrate_ready_smoke
./raw_engine_tests --case planner_structural_mixed_smoke
./raw_engine_tests --case primitive_fault_detection_smoke
./raw_engine_tests --case planner_fault_detection_smoke
./raw_engine_tests --case mutation_matrix_smoke
./raw_engine_tests --case planner_fixpoint_idempotence
./raw_engine_tests --case planner_replay_determinism
./raw_engine_tests --case reducer_determinism_smoke
./raw_engine_tests --case corpus_roundtrip_smoke
./raw_engine_tests --case corpus_replay_smoke
./raw_engine_tests --case exhaustive --family split_ready --max-real 5 --max-occ 2 --max-edges 7 --max-states 5000 --dedupe-canonical
./raw_engine_tests --case exhaustive --family mixed --max-real 5 --max-occ 3 --max-edges 8 --max-states 3000 --dedupe-canonical
./raw_engine_tests --case exhaustive --family join_ready --max-real 6 --max-occ 3 --max-edges 9 --max-components 3 --max-hosted-occ 2 --max-states 6000 --dedupe-canonical --collision-spot-checks 8
./raw_engine_tests --case exhaustive_split_ready_smoke
./raw_engine_tests --case exhaustive_join_ready_smoke
./raw_engine_tests --case exhaustive_integrate_ready_smoke
./raw_engine_tests --case exhaustive_mixed_smoke
./raw_engine_tests --case exhaustive_canonical_dedupe_smoke
./raw_engine_tests --case exhaustive_natural_dedupe_smoke
./raw_engine_tests --case exhaustive_family_sweep_smoke
./raw_engine_tests --case exhaustive_collision_guard_smoke
./raw_engine_tests --case exhaustive_natural_dedupe_large_smoke
./raw_engine_tests --case exhaustive_organic_duplicate_examples_smoke
./raw_engine_tests --case metamorphic_relabel_invariance
./raw_engine_tests --case metamorphic_occid_invariance
./raw_engine_tests --case metamorphic_edge_order_invariance
./raw_engine_tests --case metamorphic_vertex_order_invariance
./raw_engine_tests --case replay_serialization_invariance
./raw_engine_tests --case metamorphic_family_matrix_smoke
./raw_engine_tests --case metamorphic_planner_multistep_smoke
./raw_engine_tests --case metamorphic_replay_matrix_smoke
./raw_engine_tests --case split_choice_oracle_smoke
./raw_engine_tests --case split_choice_relabel_invariance
./raw_engine_tests --case split_choice_edge_order_invariance
./raw_engine_tests --case split_choice_vertex_order_invariance
./raw_engine_tests --case split_choice_oracle_regression
./raw_engine_tests --case split_choice_policy_smoke
./raw_engine_tests --case split_choice_policy_relabel_invariance
./raw_engine_tests --case split_choice_policy_edge_order_invariance
./raw_engine_tests --case split_choice_policy_vertex_order_invariance
./raw_engine_tests --case split_choice_policy_occid_invariance
./raw_engine_tests --case split_choice_policy_multiclass_smoke
./raw_engine_tests --case exact_canonicalizer_smoke
./raw_engine_tests --case fast_vs_exact_canonical_dedupe_smoke
./raw_engine_tests --case split_choice_exact_class_smoke
./raw_engine_tests --case split_choice_exact_relabel_invariance
./raw_engine_tests --case split_choice_exact_vertex_order_invariance
./raw_engine_tests --case split_choice_exact_edge_order_invariance
./raw_engine_tests --case planner_tie_mixed_smoke
./raw_engine_tests --case planner_tie_symmetric_smoke
./raw_engine_tests --case planner_tie_mixed_exhaustive_smoke
./raw_engine_tests --case planner_relabel_structural_regression
./raw_engine_tests --case exhaustive --family split_tie_ready --max-real 6 --max-occ 3 --max-edges 9 --max-states 8000 --dedupe-canonical --collision-spot-checks 8
./raw_engine_tests --case exhaustive --family split_tie_structural --max-real 6 --max-occ 3 --max-edges 9 --max-states 8000 --dedupe-canonical --collision-spot-checks 8
./raw_engine_tests --case exhaustive --family planner_tie_mixed --max-real 8 --max-occ 3 --max-edges 14 --max-states 6000 --dedupe-canonical --collision-spot-checks 8
./raw_engine_tests --case exhaustive --family split_tie_symmetric_large --max-real 8 --max-occ 3 --max-edges 12 --max-states 6000 --dedupe-canonical --collision-spot-checks 8 --exact-canonical-cap 8
./raw_engine_tests --case exhaustive --family canonical_collision_probe --max-real 8 --max-occ 3 --max-edges 12 --max-states 4000 --dedupe-canonical --collision-spot-checks 12 --exact-canonical-cap 8
./raw_engine_tests --case planner_oracle_fuzz --seed 880001 --iters 1500 --oracle planner --fuzz-mode split_tie_ready
./raw_engine_tests --case planner_oracle_fuzz --seed 880002 --iters 1500 --oracle planner --fuzz-mode planner_tie_mixed
./raw_engine_tests --case planner_oracle_fuzz --seed 880003 --iters 1500 --oracle planner --fuzz-mode planner_mixed_structural
./raw_engine_tests --case planner_oracle_fuzz --seed 900001 --iters 1500 --oracle planner --fuzz-mode split_tie_symmetric_large --save-corpus artifacts/corpus_symmetry
./raw_engine_tests --case planner_oracle_fuzz --seed 900002 --iters 1500 --oracle planner --fuzz-mode planner_tie_mixed_symmetric --save-corpus artifacts/corpus_symmetry
./raw_engine_tests --case planner_oracle_fuzz --seed 900003 --iters 1500 --oracle planner --fuzz-mode canonical_collision_probe --save-corpus artifacts/corpus_symmetry
./raw_engine_tests --case campaign --campaign-config tests/campaigns/planner_phase4.txt
./raw_engine_tests --case planner_oracle_fuzz --seed 840001 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840001_random.json --fuzz-mode random --precondition-bias-profile balanced
./raw_engine_tests --case planner_oracle_fuzz --seed 840003 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840003_weighted_join.json --fuzz-mode weighted_join_heavy
./raw_engine_tests --case planner_oracle_fuzz --seed 840005 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840005_join_ready.json --fuzz-mode join_ready
./raw_engine_tests --case planner_oracle_fuzz --seed 840007 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840007_structural_mixed.json --fuzz-mode planner_mixed_structural
```

Planner targeted coverage modes:
- `--fuzz-mode random|weighted_split_heavy|weighted_join_heavy|weighted_integrate_heavy|artifact_heavy|multiedge_heavy`
- `--fuzz-mode split_ready|split_with_boundary_artifact|split_with_keepOcc_sibling|split_with_join_and_integrate|planner_mixed_targeted|join_ready|integrate_ready|planner_mixed_structural`
- `--fuzz-mode split_tie_ready|split_tie_structural|planner_tie_mixed|split_tie_symmetric_large|planner_tie_mixed_symmetric|canonical_collision_probe|split_tie_organic_symmetric|planner_tie_mixed_organic|automorphism_probe_large` adds tie-heavy and symmetry-heavy planner families
- `--scenario-family random|split_ready|split_with_boundary_artifact|split_with_keepOcc_sibling|split_with_join_and_integrate|planner_mixed_targeted|join_ready|integrate_ready|planner_mixed_structural|split_tie_ready|split_tie_structural|planner_tie_mixed|split_tie_symmetric_large|planner_tie_mixed_symmetric|canonical_collision_probe|split_tie_organic_symmetric|planner_tie_mixed_organic|automorphism_probe_large`
- `--precondition-bias-profile default|balanced|split_heavy|join_heavy|integrate_heavy|artifact_heavy|structural`
- `--bias-split <0..8>` / `--bias-join <0..8>` / `--bias-integrate <0..8>` override the active bias profile per primitive family
- `--stats` / `--stats-file` emit JSON plus `<stats>.summary.txt`
- `--save-corpus <dir>` / `--load-corpus <dir>` / `--corpus-policy best|append|replace` persist and replay high-value planner seeds
- `--case campaign --campaign-config tests/campaigns/planner_phase4.txt` runs a long planner campaign and emits aggregate stats/summary files
- `--case exhaustive --family split_ready|join_ready|integrate_ready|mixed|split_tie_ready|split_tie_structural|planner_tie_mixed|split_tie_symmetric_large|planner_tie_mixed_symmetric|canonical_collision_probe|split_tie_organic_symmetric|planner_tie_mixed_organic|automorphism_probe_large|all --max-real <N> --max-occ <N> --max-edges <N> --max-components <N> --max-hosted-occ <N> --max-states <N> --dedupe-canonical --collision-spot-checks <N> --exact-canonical-cap <N> --exact-canonical-sample-rate <N>` runs the bounded tiny-state explorer with natural dedupe stats, optional sampled collision guards, and bounded exact-canonical audit
- `--max-split-pair-candidates <N>` bounds split-choice oracle comparison while always keeping the planner-selected pair in the compared subset
- `--max-split-choice-eval <N>` caps semantic split-choice lookahead evaluation; over-cap choices fall back to deterministic structural ranking and increment fallback stats
- `--exact-canonical-cap <N>` bounds the tests-only exact canonicalizer by live REAL-orig count
- `--exact-canonical-sample-rate <N>` samples exhaustive states for exact canonical audit; `1` audits every eligible state
- `--exact-audit-sample-rate <float>` samples split-choice exact audits during planner fuzz
- `--exact-audit-budget <N>` limits the number of split-choice exact audits per run
- `--exact-audit-family <scenario-family>` restricts sampled exact audits to one targeted family
- `--split-choice-policy fast|exact_shadow` defaults production and tests to `exact_shadow`; `fast` remains available for comparison, fallback, and regression reproduction
- `split_choice_oracle_*` cases enumerate admissible split pairs, compare final canonical state / target isolate signature / stop condition, and route detected instability through dump/reduce/regression
- `split_choice_policy_*` cases verify that the planner chooses a relabel/order invariant semantic representative across admissible split pairs and multi-class tie states
- `split_choice_representative_shift_*` and sampled exact-audit fuzz stats classify representative shifts as `harmless`, `trace_only`, or `semantic`
- `split_choice_semantic_shift_regression` replays a saved sampled exact-audit counterexample and pins the current fast-policy semantic shift against the exact-shadow representative
- `exact_canonicalizer_smoke`, `fast_vs_exact_canonical_dedupe_smoke`, `split_choice_exact_*`, `planner_tie_symmetric_smoke`, and `canonical_collision_probe_smoke` extend the deterministic quality gates with tests-only exact canonicalization, fast-vs-exact dedupe audit, symmetry-heavy split-choice class audit, and canonical-collision probes
- `split_tie_organic_symmetric_smoke`, `planner_tie_mixed_organic_smoke`, `automorphism_probe_large_smoke`, `sampled_exact_audit_smoke`, and `duplicate_attribution_smoke` cover the organic-symmetry families, sampled larger-state exact audit, and duplicate-cause attribution
- `exhaustive_*_smoke`, `metamorphic_*`, `split_choice_oracle_*`, and `split_choice_policy_*` remain the deterministic quality gates for natural canonical dedupe, relabel/occid/order invariance, planner multi-step matrix coverage, replay serialization invariance, split-pair stability, and semantic split-choice selection
- stats include:
  - preconditions and actual hits: `split_ready_count`, `boundary_only_child_count`, `join_candidate_count`, `integrate_candidate_count`, `actual_split_hits`, `actual_join_hits`, `actual_integrate_hits`, `first_*_iter`
  - conversion ratios: `precondition_to_actual.split_conversion`, `join_conversion`, `integrate_conversion`
  - diversity: `trace_prefix_histogram`, `primitive_multiset_histogram`, `diversity.unique_trace_prefix_count`, `diversity.unique_primitive_multiset_count`
  - coverage summary: `coverage_summary.isolate_heavy_ratio`, `split_hit_density`, `join_hit_density`, `integrate_hit_density`
  - split-choice policy: `split_choice_candidate_count`, `split_choice_eval_count`, `split_choice_tie_count`, `split_choice_multiclass_count`, `split_choice_fallback_count`, `split_choice_equiv_class_count_histogram`, `first_split_choice_tie_iter`
  - representative-shift audit: `representative_shift_count`, `representative_shift_same_class_count`, `representative_shift_semantic_divergence_count`, `representative_shift_followup_divergence_count`, `representative_shift_trace_divergence_count`, `harmless_shift_count`, `trace_only_shift_count`, `semantic_shift_count`
  - fast-vs-exact audit: `exact_audited_state_count`, `exact_audited_pair_count`, `fast_unique_count`, `exact_unique_count`, `fast_vs_exact_disagreement_count`, `false_merge_count`, `false_split_count`, `exact_audit_skipped_cap_count`, `exact_audit_skipped_budget_count`, `exact_audit_skipped_sample_count`, `exact_audit_skipped_family_count`, `exact_audit_skipped_non_tie_count`
  - sampled duplicate attribution: `build_order_duplicate_count`, `commit_order_duplicate_count`, `hosted_occ_order_duplicate_count`, `relabel_duplicate_count`, `occid_duplicate_count`, `symmetric_structure_duplicate_count`, `mixed_duplicate_count`, `unknown_duplicate_count`

Build and run:
```bash
bash build_and_run.sh
```

If `cmake` / `ctest` are not on `PATH`, pass them explicitly:
```bash
CMAKE_BIN=/path/to/cmake CTEST_BIN=/path/to/ctest bash build_and_run.sh
```

Manual commands:
```bash
cmake -S . -B build-debug -DCMAKE_BUILD_TYPE=Debug
cmake --build build-debug -j
ctest --test-dir build-debug --output-on-failure
```

Optional warning hygiene for tests only:
```bash
cmake -S . -B build-debug-strict -DCMAKE_BUILD_TYPE=Debug -DRAW_ENGINE_TEST_STRICT_WARNINGS=ON
cmake --build build-debug-strict -j
```

Known fixed repros:
```bash
./raw_engine_tests --case regression_44001
./raw_engine_tests --case regression_isolate_split_no_sep
```

Coverage quality gates:
- `exhaustive_split_ready_smoke`
- `exhaustive_join_ready_smoke`
- `exhaustive_integrate_ready_smoke`
- `exhaustive_mixed_smoke`
- `exhaustive_canonical_dedupe_smoke`
- `exhaustive_natural_dedupe_smoke`
- `exhaustive_family_sweep_smoke`
- `exhaustive_collision_guard_smoke`
- `exhaustive_natural_dedupe_large_smoke`
- `exhaustive_organic_duplicate_examples_smoke`
- `metamorphic_relabel_invariance`
- `metamorphic_occid_invariance`
- `metamorphic_edge_order_invariance`
- `metamorphic_vertex_order_invariance`
- `replay_serialization_invariance`
- `metamorphic_family_matrix_smoke`
- `metamorphic_planner_multistep_smoke`
- `metamorphic_replay_matrix_smoke`
- `split_choice_oracle_smoke`
- `split_choice_relabel_invariance`
- `split_choice_edge_order_invariance`
- `split_choice_vertex_order_invariance`
- `split_choice_oracle_regression`
- `split_choice_policy_smoke`
- `split_choice_policy_relabel_invariance`
- `split_choice_policy_edge_order_invariance`
- `split_choice_policy_vertex_order_invariance`
- `split_choice_policy_occid_invariance`
- `split_choice_policy_multiclass_smoke`
- `exact_canonicalizer_smoke`
- `fast_vs_exact_canonical_dedupe_smoke`
- `split_choice_exact_class_smoke`
- `split_choice_exact_relabel_invariance`
- `split_choice_exact_vertex_order_invariance`
- `split_choice_exact_edge_order_invariance`
- `planner_relabel_structural_regression`
- `planner_targeted_split_smoke`
- `planner_targeted_join_smoke`
- `planner_targeted_integrate_smoke`
- `planner_targeted_mixed_smoke`
- `planner_coverage_smoke`
- `planner_random_coverage_smoke`
- `planner_weighted_coverage_smoke`
- `planner_join_ready_smoke`
- `planner_integrate_ready_smoke`
- `planner_structural_mixed_smoke`
- `planner_tie_mixed_smoke`
- `planner_tie_mixed_exhaustive_smoke`
- `planner_tie_symmetric_smoke`
- `canonical_collision_probe_smoke`
- `split_choice_representative_shift_smoke`
- `split_choice_harmless_shift_smoke`
- `split_choice_semantic_shift_smoke`
- `split_choice_semantic_shift_regression`
- `split_tie_organic_symmetric_smoke`
- `planner_tie_mixed_organic_smoke`
- `automorphism_probe_large_smoke`
- `sampled_exact_audit_smoke`
- `duplicate_attribution_smoke`

Sync policy:
- `include/`, `src/`, `tests/`, `CMakeLists.txt` are the authoritative source tree.
- `raw_engine_v1.cpp` is a compatibility/export artifact, not the source of truth.
- New implementation/debug/test work must land in the split source tree first.
- If a standalone snapshot is needed again, regenerate/export from the split tree instead of patching `raw_engine_v1.cpp` directly.
