# raw_engine_v1 package

First-working-version raw primitive engine, split into a small CMake project.

Structure:
- `include/raw_engine/raw_engine.hpp`
- `src/raw_core.cpp`
- `src/raw_validators.cpp`
- `src/raw_primitives.cpp`
- `src/raw_planner.cpp`
- `tests/raw_engine_cases.cpp`
- `tests/exhaustive_generator.cpp`
- `tests/exhaustive_cases.cpp`
- `tests/metamorphic_cases.cpp`
- `tests/split_choice_oracle.cpp`
- `tests/split_choice_cases.cpp`
- `tests/raw_engine_main.cpp`

Primary target:
- `raw_engine_tests`

CLI examples:
```bash
./raw_engine_tests --case micro
./raw_engine_tests --case fuzz --seed 44001 --iters 1
./raw_engine_tests --case planner --seed 123 --iters 1000
./raw_engine_tests --case fuzz_matrix --iters 20
./raw_engine_tests --case isolate_fuzz --seed 710001 --iters 100
./raw_engine_tests --case split_join_fuzz --seed 715001 --iters 100
./raw_engine_tests --case planner_mixed_fuzz --seed 717001 --iters 100 --step-budget 200000
./raw_engine_tests --case regression_44001
./raw_engine_tests --case regression_isolate_split_no_sep
./raw_engine_tests --case repro --repro-file counterexamples/reduced_isolate_split_seed3736675150.txt
./raw_engine_tests --case planner_targeted_mixed_smoke
./raw_engine_tests --case planner_coverage_smoke
./raw_engine_tests --case planner_random_coverage_smoke
./raw_engine_tests --case planner_weighted_coverage_smoke
./raw_engine_tests --case planner_join_ready_smoke
./raw_engine_tests --case planner_integrate_ready_smoke
./raw_engine_tests --case planner_structural_mixed_smoke
./raw_engine_tests --case primitive_fault_detection_smoke
./raw_engine_tests --case planner_fault_detection_smoke
./raw_engine_tests --case mutation_matrix_smoke
./raw_engine_tests --case planner_fixpoint_idempotence
./raw_engine_tests --case planner_replay_determinism
./raw_engine_tests --case reducer_determinism_smoke
./raw_engine_tests --case corpus_roundtrip_smoke
./raw_engine_tests --case corpus_replay_smoke
./raw_engine_tests --case exhaustive --family split_ready --max-real 5 --max-occ 2 --max-edges 7 --max-states 5000 --dedupe-canonical
./raw_engine_tests --case exhaustive --family mixed --max-real 5 --max-occ 3 --max-edges 8 --max-states 3000 --dedupe-canonical
./raw_engine_tests --case exhaustive --family join_ready --max-real 6 --max-occ 3 --max-edges 9 --max-components 3 --max-hosted-occ 2 --max-states 6000 --dedupe-canonical --collision-spot-checks 8
./raw_engine_tests --case exhaustive_split_ready_smoke
./raw_engine_tests --case exhaustive_join_ready_smoke
./raw_engine_tests --case exhaustive_integrate_ready_smoke
./raw_engine_tests --case exhaustive_mixed_smoke
./raw_engine_tests --case exhaustive_canonical_dedupe_smoke
./raw_engine_tests --case exhaustive_natural_dedupe_smoke
./raw_engine_tests --case exhaustive_family_sweep_smoke
./raw_engine_tests --case exhaustive_collision_guard_smoke
./raw_engine_tests --case exhaustive_natural_dedupe_large_smoke
./raw_engine_tests --case exhaustive_organic_duplicate_examples_smoke
./raw_engine_tests --case metamorphic_relabel_invariance
./raw_engine_tests --case metamorphic_occid_invariance
./raw_engine_tests --case metamorphic_edge_order_invariance
./raw_engine_tests --case metamorphic_vertex_order_invariance
./raw_engine_tests --case replay_serialization_invariance
./raw_engine_tests --case metamorphic_family_matrix_smoke
./raw_engine_tests --case metamorphic_planner_multistep_smoke
./raw_engine_tests --case metamorphic_replay_matrix_smoke
./raw_engine_tests --case split_choice_oracle_smoke
./raw_engine_tests --case split_choice_relabel_invariance
./raw_engine_tests --case split_choice_edge_order_invariance
./raw_engine_tests --case split_choice_vertex_order_invariance
./raw_engine_tests --case split_choice_oracle_regression
./raw_engine_tests --case planner_tie_mixed_smoke
./raw_engine_tests --case planner_relabel_structural_regression
./raw_engine_tests --case exhaustive --family split_tie_ready --max-real 6 --max-occ 3 --max-edges 9 --max-states 8000 --dedupe-canonical --collision-spot-checks 8
./raw_engine_tests --case exhaustive --family planner_tie_mixed --max-real 8 --max-occ 3 --max-edges 14 --max-states 6000 --dedupe-canonical --collision-spot-checks 8
./raw_engine_tests --case planner_oracle_fuzz --seed 880001 --iters 1500 --oracle planner --fuzz-mode split_tie_ready
./raw_engine_tests --case planner_oracle_fuzz --seed 880002 --iters 1500 --oracle planner --fuzz-mode planner_tie_mixed
./raw_engine_tests --case campaign --campaign-config tests/campaigns/planner_phase4.txt
./raw_engine_tests --case planner_oracle_fuzz --seed 840001 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840001_random.json --fuzz-mode random --precondition-bias-profile balanced
./raw_engine_tests --case planner_oracle_fuzz --seed 840003 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840003_weighted_join.json --fuzz-mode weighted_join_heavy
./raw_engine_tests --case planner_oracle_fuzz --seed 840005 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840005_join_ready.json --fuzz-mode join_ready
./raw_engine_tests --case planner_oracle_fuzz --seed 840007 --iters 2000 --step-budget 200000 --oracle planner --dump-on-fail --artifact-dir build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3 --stats-file build-release/tests/artifacts/planner_fuzz_phase_20260307_phase3/logs/seed840007_structural_mixed.json --fuzz-mode planner_mixed_structural
```

Planner targeted coverage modes:
- `--fuzz-mode random|weighted_split_heavy|weighted_join_heavy|weighted_integrate_heavy|artifact_heavy|multiedge_heavy`
- `--fuzz-mode split_ready|split_with_boundary_artifact|split_with_keepOcc_sibling|split_with_join_and_integrate|planner_mixed_targeted|join_ready|integrate_ready|planner_mixed_structural`
- `--fuzz-mode split_tie_ready|split_tie_structural|planner_tie_mixed` adds tie-heavy planner families
- `--scenario-family random|split_ready|split_with_boundary_artifact|split_with_keepOcc_sibling|split_with_join_and_integrate|planner_mixed_targeted|join_ready|integrate_ready|planner_mixed_structural|split_tie_ready|split_tie_structural|planner_tie_mixed`
- `--precondition-bias-profile default|balanced|split_heavy|join_heavy|integrate_heavy|artifact_heavy|structural`
- `--bias-split <0..8>` / `--bias-join <0..8>` / `--bias-integrate <0..8>` override the active bias profile per primitive family
- `--stats` / `--stats-file` emit JSON plus `<stats>.summary.txt`
- `--save-corpus <dir>` / `--load-corpus <dir>` / `--corpus-policy best|append|replace` persist and replay high-value planner seeds
- `--case campaign --campaign-config tests/campaigns/planner_phase4.txt` runs a long planner campaign and emits aggregate stats/summary files
- `--case exhaustive --family split_ready|join_ready|integrate_ready|mixed|split_tie_ready|split_tie_structural|planner_tie_mixed|all --max-real <N> --max-occ <N> --max-edges <N> --max-components <N> --max-hosted-occ <N> --max-states <N> --dedupe-canonical --collision-spot-checks <N>` runs the bounded tiny-state explorer with natural dedupe stats and optional sampled collision guards
- `--max-split-pair-candidates <N>` bounds split-choice oracle comparison while always keeping the planner-selected pair in the compared subset
- `split_choice_*` cases enumerate admissible split pairs, compare final canonical state / target isolate signature / stop condition, and route detected instability through dump/reduce/regression
- `exhaustive_*_smoke`, `metamorphic_*`, and `split_choice_*` are deterministic CTest quality gates for natural canonical dedupe, relabel/occid/order invariance, planner multi-step matrix coverage, replay serialization invariance, and split-pair stability
- stats include:
  - preconditions and actual hits: `split_ready_count`, `boundary_only_child_count`, `join_candidate_count`, `integrate_candidate_count`, `actual_split_hits`, `actual_join_hits`, `actual_integrate_hits`, `first_*_iter`
  - conversion ratios: `precondition_to_actual.split_conversion`, `join_conversion`, `integrate_conversion`
  - diversity: `trace_prefix_histogram`, `primitive_multiset_histogram`, `diversity.unique_trace_prefix_count`, `diversity.unique_primitive_multiset_count`
  - coverage summary: `coverage_summary.isolate_heavy_ratio`, `split_hit_density`, `join_hit_density`, `integrate_hit_density`

Build and run:
```bash
bash build_and_run.sh
```

If `cmake` / `ctest` are not on `PATH`, pass them explicitly:
```bash
CMAKE_BIN=/path/to/cmake CTEST_BIN=/path/to/ctest bash build_and_run.sh
```

Manual commands:
```bash
cmake -S . -B build-debug -DCMAKE_BUILD_TYPE=Debug
cmake --build build-debug -j
ctest --test-dir build-debug --output-on-failure
```

Optional warning hygiene for tests only:
```bash
cmake -S . -B build-debug-strict -DCMAKE_BUILD_TYPE=Debug -DRAW_ENGINE_TEST_STRICT_WARNINGS=ON
cmake --build build-debug-strict -j
```

Known fixed repros:
```bash
./raw_engine_tests --case regression_44001
./raw_engine_tests --case regression_isolate_split_no_sep
```

Coverage quality gates:
- `exhaustive_split_ready_smoke`
- `exhaustive_join_ready_smoke`
- `exhaustive_integrate_ready_smoke`
- `exhaustive_mixed_smoke`
- `exhaustive_canonical_dedupe_smoke`
- `exhaustive_natural_dedupe_smoke`
- `exhaustive_family_sweep_smoke`
- `exhaustive_collision_guard_smoke`
- `exhaustive_natural_dedupe_large_smoke`
- `exhaustive_organic_duplicate_examples_smoke`
- `metamorphic_relabel_invariance`
- `metamorphic_occid_invariance`
- `metamorphic_edge_order_invariance`
- `metamorphic_vertex_order_invariance`
- `replay_serialization_invariance`
- `metamorphic_family_matrix_smoke`
- `metamorphic_planner_multistep_smoke`
- `metamorphic_replay_matrix_smoke`
- `split_choice_oracle_smoke`
- `split_choice_relabel_invariance`
- `split_choice_edge_order_invariance`
- `split_choice_vertex_order_invariance`
- `split_choice_oracle_regression`
- `planner_relabel_structural_regression`
- `planner_targeted_split_smoke`
- `planner_targeted_join_smoke`
- `planner_targeted_integrate_smoke`
- `planner_targeted_mixed_smoke`
- `planner_coverage_smoke`
- `planner_random_coverage_smoke`
- `planner_weighted_coverage_smoke`
- `planner_join_ready_smoke`
- `planner_integrate_ready_smoke`
- `planner_structural_mixed_smoke`
- `planner_tie_mixed_smoke`

Sync policy:
- `include/`, `src/`, `tests/`, `CMakeLists.txt` are the authoritative source tree.
- `raw_engine_v1.cpp` is a compatibility/export artifact, not the source of truth.
- New implementation/debug/test work must land in the split source tree first.
- If a standalone snapshot is needed again, regenerate/export from the split tree instead of patching `raw_engine_v1.cpp` directly.
