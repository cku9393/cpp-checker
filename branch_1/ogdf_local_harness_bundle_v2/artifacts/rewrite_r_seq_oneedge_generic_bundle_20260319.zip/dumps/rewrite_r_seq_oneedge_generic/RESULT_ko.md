# RESULT_ko

- rewriteSeqCalls = 110100
- seqFallbackCaseCount = 683 (baseline 824 대비 -141)
- seqRewriteWholeCoreFallbackCount = 683 (baseline 1507 대비 -824)
- RFT_COMPACT_TOO_SMALL_UNHANDLED = 0 (baseline 824 대비 -824)
- seqTooSmallOneEdgeHandledCount = 824
- seqTooSmallOneEdgeRealNonLoopHandledCount = 824
- seqTooSmallOneEdgeFallbackCount = 0
- dominant remaining trigger = RFT_COMPACT_BUILD_FAIL (562)

correctness는 s1_r100, s1_r1000, seed=1..10 x 1000, seed=1..20 x 5000 모두 green이다.
