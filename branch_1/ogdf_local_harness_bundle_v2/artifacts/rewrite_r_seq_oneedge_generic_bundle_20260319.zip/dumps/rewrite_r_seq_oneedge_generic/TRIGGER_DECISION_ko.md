# TRIGGER_DECISION_ko

- current dominant remaining trigger = RFT_COMPACT_BUILD_FAIL
- trigger count = 562
- representative subtype = CBF_SELF_LOOP_PRECHECK
- next safe fix target = compact build fail / CBF_SELF_LOOP_PRECHECK
- 이번 단계에서는 behavior 변경 포함
