# RESULT

- correctness: green
- representative replay: `seed=2, tc=444, step=1` green
- seqSelfLoopRemainderOneEdgeAttemptCount: 148
- seqSelfLoopRemainderOneEdgeHandledCount: 148
- seqSelfLoopRemainderOneEdgeFallbackCount: 0
- CBF_SELF_LOOP_PRECHECK: 148 -> 0
- SL_PROXY_ONLY_REMAINDER_OTHER_NOT_BICONNECTED: 148 -> 0
- seqFallbackCaseCount: 269 -> 121
- seqRewriteWholeCoreFallbackCount: 269 -> 121

Current dominant remaining trigger is `RFT_X_INCIDENT_VIRTUAL_UNSUPPORTED` = 121. Representative residual subtype is `XSR_HAFTER_SPQR_READY` = 121. Next safe fix target is `x-incident residual / XSR_HAFTER_SPQR_READY`.
