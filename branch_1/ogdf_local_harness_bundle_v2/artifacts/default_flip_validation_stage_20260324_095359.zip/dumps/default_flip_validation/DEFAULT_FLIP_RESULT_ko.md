# DEFAULT FLIP RESULT

- default solver path: rewrite-seq
- hard compare: 6 passed / 0 failed
- random sanity: 11100 passed / 0 failed
- oracle-vs-rewrite mismatch count: 0
- explicit mismatch count: 0
- all summaries validated: true
- legacy path status: diagnostic-only
- direct solver smoke: passed (`--mode rewrite-seq --seed 1 --rounds 10`)

## Stages

- `s1_r100`: green
- `s1_r1000`: green
- `s1..s10_r1000`: green

## Notes

- Hard compare stayed green under default flip and oracle normalize baseline.
- Summary writing stayed atomic and validated across all stored summaries.
- Standalone `s1_r1000` and loop seed 1 reused the same dump directory name on disk; executed stage totals above follow the validation plan.
