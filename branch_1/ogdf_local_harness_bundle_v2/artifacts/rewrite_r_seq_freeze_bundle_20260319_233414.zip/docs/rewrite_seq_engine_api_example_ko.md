# Rewrite Seq Engine API Example

```cpp
#include "harness/project_static_adapter.hpp"

using namespace harness;

bool optimizeReducedCoreForSolver(ReducedSPQRCore &core, std::string &why) {
    RewriteSeqStats stats;
    if (!runRewriteSequenceToFixpoint(core, stats, why)) {
        return false;
    }

    // Optional debug logging at integration time.
    std::cerr << "rewriteSeq completedSteps=" << stats.completedSteps
              << " reachedFixpoint=" << stats.reachedFixpoint
              << " hadSequenceFallback=" << stats.hadSequenceFallback
              << " seqFallbackCaseCountDelta=" << stats.seqFallbackCaseCountDelta
              << " seqRewriteWholeCoreFallbackCountDelta="
              << stats.seqRewriteWholeCoreFallbackCountDelta
              << "\n";
    return true;
}
```

주의:

- 이 API는 이미 build 된 `ReducedSPQRCore`를 입력으로 받는다.
- 현재 harness의 `rewrite-r-seq` loop와 같은 순서로 rewrite, normalize, invariant, oracle compare를 수행한다.
- 실패 시 `why`에 가장 이른 실패 이유를 남긴다.
