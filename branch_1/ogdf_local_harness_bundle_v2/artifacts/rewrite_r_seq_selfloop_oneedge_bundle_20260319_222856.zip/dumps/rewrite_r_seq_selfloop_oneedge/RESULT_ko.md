sequence-only self-loop tiny one-edge path를 추가했고 representative replay(seed=2, tc=444, step=1)는 green입니다.

집계 기준은 s1_r100 + per-seed full_s1_10_r1000 + per-seed clean full_s1_20_r5000이며, s1_r1000는 seed1 중복이라 제외했습니다. 이 기준에서 rewriteSeqCalls=110100, seqFallbackCaseCount=121, seqRewriteWholeCoreFallbackCount=121 입니다.

핵심 감소폭은 CBF_SELF_LOOP_PRECHECK 148 -> 0, SL_PROXY_ONLY_REMAINDER_OTHER_NOT_BICONNECTED 148 -> 0, seqFallbackCaseCount 269 -> 121, seqRewriteWholeCoreFallbackCount 269 -> 121 입니다. 새 path stats는 attempt=148, handled=148, fallback=0 입니다.

남은 dominant trigger는 RFT_X_INCIDENT_VIRTUAL_UNSUPPORTED=121이고 representative subtype은 XSR_HAFTER_SPQR_READY 입니다. 다음 safe fix target은 x-incident residual / XSR_HAFTER_SPQR_READY 입니다.
