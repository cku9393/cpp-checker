current dominant remaining trigger = RFT_X_INCIDENT_VIRTUAL_UNSUPPORTED
trigger count = 121
representative subtype = XSR_HAFTER_SPQR_READY
next safe fix target = x-incident residual / XSR_HAFTER_SPQR_READY
이번 단계에서는 sequence-only self-loop tiny one-edge handling 추가
