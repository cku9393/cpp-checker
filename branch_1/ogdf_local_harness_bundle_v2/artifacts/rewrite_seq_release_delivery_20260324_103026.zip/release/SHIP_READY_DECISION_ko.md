# SHIP READY DECISION

- default solver path: `rewrite-seq`
- hard compare status: `green`
- random sanity status: `green`
- direct smoke status: `green`
- legacy path status: `diagnostic-only`
- release bundle path: `artifacts/rewrite_seq_release_delivery_20260324_103026.zip`

## Rollback Policy
- 운영 rollback이 필요하면 legacy path를 기본값으로 되돌리는 대신 diagnostic-only로만 호출한다.
- direct legacy diagnostic:
  - `./build/rewrite_r_harness --backend ogdf --mode rewrite-r --seed 1 --rounds 10 --dump-dir dumps/legacy_diagnostic_smoke`
- compare diagnostic:
  - `./build/rewrite_r_harness --backend ogdf --mode solver-compare --manifest regressions/rewrite_seq_cases.json --baseline legacy --dump-dir dumps/legacy_compare_diagnostic`

## Open Risk / Known Limitation
- random compare의 release gate는 현재 `seed=1`, `rounds=100` sanity 기준이다.
- broader random campaign은 필요 시 별도 release sanity로 확장한다.
- summary writer parse fail은 behavior issue가 아니라 artifact issue로 분리해서 다룬다.

## Verdict
- 현재 release gate는 green이고, handoff 산출물과 operator runbook도 준비됐다.
- 이 상태는 merge/tag/hand-off 가능한 ship-ready 상태로 본다.
