이번 단계는 `SL_PROXY_ONLY_REMAINDER_OTHER_NOT_BICONNECTED`를 block-cut subtype 으로만 다시 쪼갠 계측 단계입니다. behavior 는 그대로 두고 full campaign 을 다시 돌렸습니다.

dedup aggregate 기준으로 `rewriteSeqCalls=110100`, `seqFallbackCaseCount=269`, `seqRewriteWholeCoreFallbackCount=269`이며 correctness 는 계속 green 입니다. baseline `rewrite_r_seq_selfloop_spqrready` 대비 전체 fallback 수치는 그대로 유지됐습니다. `CBF_SELF_LOOP_PRECHECK=148`, `SL_PROXY_ONLY_REMAINDER_OTHER_NOT_BICONNECTED=148`입니다.

새 계측 결과는 `SLNB_DISCONNECTED=0`, `SLNB_STAR_AROUND_ONE_CUT=0`, `SLNB_COMPLEX_MULTI_CUT=0`, `SLNB_BLOCKS_ALL_TINY=148`, `SLNB_OTHER=0`입니다. 즉 현재 분류기로는 residual self-loop other-not-biconnected 가 전부 `SLNB_OTHER`로 남아서, 다음 safe target 은 handler 추가가 아니라 finer subtype 설계입니다. 대표 샘플 dump 는 `-`입니다.
