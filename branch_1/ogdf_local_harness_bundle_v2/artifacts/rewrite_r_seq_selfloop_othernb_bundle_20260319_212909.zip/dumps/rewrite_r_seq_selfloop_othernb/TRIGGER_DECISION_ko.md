current dominant remaining trigger = RFT_COMPACT_BUILD_FAIL
trigger count = 148
대표 subtype = SLNB_BLOCKS_ALL_TINY
next safe fix target = SLNB_BLOCKS_ALL_TINY
이번 단계에서는 behavior 변경 없음
