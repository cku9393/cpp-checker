#!/usr/bin/env bash
set -euo pipefail

for base in "$@" /opt/homebrew /usr/local /usr "$HOME/.local" "$PWD/.deps/ogdf-install"; do
  [ -e "$base" ] || continue
  while IFS= read -r p; do
    dir=$(dirname "$(dirname "$p")")
    echo "$dir"
  done < <(find "$base" -name StaticSPQRTree.h 2>/dev/null)
done | awk '!seen[$0]++'
