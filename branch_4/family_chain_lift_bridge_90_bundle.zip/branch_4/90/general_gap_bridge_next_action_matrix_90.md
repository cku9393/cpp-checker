# General Gap Bridge Next Action Matrix 90

## recommendation

Top recommendation: `family_chain_lift_map_refinement`.

Second recommendation: `prove_support_reduction_operation_sublemma`.

Third recommendation: `higher_support_necessity_recheck`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `family_chain_lift_map_refinement` | 82 | 91 | 66 | 68 | 88 | 90 | 1 | `family_chain_lift_map_refinement` |
| `prove_support_reduction_operation_sublemma` | 72 | 88 | 76 | 76 | 80 | 84 | 2 | `prove_support_reduction_operation_sublemma` |
| `higher_support_necessity_recheck` | 70 | 84 | 58 | 64 | 88 | 80 | 3 | `higher_support_necessity_recheck` |
| `limited_to_broader_generalization_plan` | 64 | 80 | 55 | 60 | 82 | 72 | 4 | `limited_to_broader_generalization_plan` |
| `formalize_support_bound_completion` | 58 | 78 | 62 | 68 | 76 | 70 | 5 | `formalize_support_bound_completion` |
| `boj_problem_bridge_formalization` | 42 | 60 | 50 | 50 | 58 | 52 | 6 | `boj_problem_bridge_formalization` |

## rationale

`family_chain_lift_bridge` proved target-package readiness and conditional bounded-theorem applicability, but it did not prove source-form recognition or obstruction-preserving lift-map correctness for arbitrary support-growth witnesses. The next blocker is therefore `family_chain_lift_map_refinement`.
