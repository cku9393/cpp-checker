# Support Reduction Sublemma Proofs 90

## update after family-chain lift

The family-chain branch now has target-package freshness and conditional applicability. It is still blocked by lift-map correctness.

- `proved_under_current_scope`: `3`
- `proof_sketch_only`: `2`
- `blocked`: `1`

Runtime proofs: `branch_4/90/runtime/support_reduction_sublemma_proofs_90.tsv`.
