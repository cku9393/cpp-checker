# Higher-Support Escape Interface 90

## summary

Support `>8` non-reduced witnesses remain named as `higher_support_escape`; family-chain lift now narrows one branch but does not close it.

Status:

`higher_support_escape_interface_lift_partial_open`.

This blocks broader and full general theorem statements, but it does not block the already proved selected limited bridge theorem. The next proof-side target is `family_chain_lift_map_refinement`, not support9+ expansion.

Runtime table: `branch_4/90/runtime/higher_support_escape_interface_90.tsv`.
