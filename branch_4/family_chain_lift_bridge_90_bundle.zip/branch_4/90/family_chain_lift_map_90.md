# Family-Chain Lift Map 90

## lift map contract

The lift map is currently a proof contract, not a completed theorem. It identifies how a support-growth witness would be mapped into the bounded family-chain obstruction language if source-form and preservation sublemmas are proved.

The verified part is target-package readiness: when the map reaches pair/triple/quadruple/quintuple/sextuple/septuple/high-family layers, those layers are fresh current-runtime generated and non-imported. The open part is the source-to-target correctness of the map.

Runtime table: `branch_4/90/runtime/family_chain_lift_map_90.tsv`.
