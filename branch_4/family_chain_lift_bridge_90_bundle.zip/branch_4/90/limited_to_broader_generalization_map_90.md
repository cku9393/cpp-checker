# Limited To Broader Generalization Map 90

## map summary

The limited support8 theorem is proved under current scope. Family-chain lift now refines the family-chain branch:

- support `<=8` is handled by the limited theorem;
- support `>8` reducible cases still need operation preservation;
- family-chain support-growth cases have target package readiness but need lift-map refinement;
- irreducible cases remain `higher_support_escape`.

Runtime map: `branch_4/90/runtime/limited_to_broader_generalization_map_90.tsv`.
