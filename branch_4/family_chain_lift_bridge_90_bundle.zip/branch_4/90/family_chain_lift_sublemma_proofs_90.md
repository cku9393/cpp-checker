# Family-Chain Lift Sublemma Proofs 90

## proof attempt result

The proof attempt proves current-scope target facts:

- the family-chain target layers are fresh `7/7`;
- the bounded family-chain theorem can be applied after a successful lift;
- self verification applies after a successful lift;
- failed lift remains a named `higher_support_escape`.

It does not prove that every support-growth witness has a family-chain source form, nor that the lift preserves obstruction status.

Runtime proofs: `branch_4/90/runtime/family_chain_lift_sublemma_proofs_90.tsv`.
