# General Gap Bridge Dependency Graph 90

## family-chain lift update

New edge state:

- `family_chain_lift_skeleton` supports `family_chain_lift` as a partial lift theorem.
- `family_chain_lift_map` still blocks completion of `family_chain_lift`.
- `higher_support_escape_interface` remains open for failed lift cases.

Runtime graph: `branch_4/90/runtime/general_gap_bridge_dependency_graph_90.tsv`.
