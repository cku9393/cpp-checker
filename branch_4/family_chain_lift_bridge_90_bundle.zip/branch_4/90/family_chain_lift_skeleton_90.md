# Family-Chain Lift Skeleton 90

## lemma

`family_chain_lift_or_higher_support_escape`.

## exact statement

For a support `>8` normal witness in the family-chain branch of `support_growth_partition`, either:

1. the witness has a well-defined lift into the current bounded family-chain obstruction language, in which case the fresh family-chain package is the correct target package and the bounded theorem applies conditionally; or
2. the lift source form or preservation proof is missing, in which case the witness remains a named `higher_support_escape` or `family_chain_lift_map_refinement` obligation.

## proof outline

1. Put the witness in support-growth normal form.
2. Identify the family-chain source component.
3. Apply the lift map to a target layer: pair52, triple53, quad55, quintuple57, sextuple57, septuple57, or high57.
4. Use the lower-layer fingerprint to prove the target package is fresh `7/7`.
5. If the lift succeeds, apply the bounded family-chain theorem and self verification.
6. If source-form recognition or obstruction preservation fails, route to `higher_support_escape` and `family_chain_lift_map_refinement`.
7. Record that full support8 sufficiency and full general theorem remain unproved.

## final status

`partial_lift_proved_escape_open`.

The current proof proves target-package freshness and conditional bounded-theorem applicability. It does not prove arbitrary support-growth source-form recognition or obstruction-preserving lift correctness.

Runtime skeleton: `branch_4/90/runtime/family_chain_lift_skeleton_90.tsv`.
