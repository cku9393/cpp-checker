# Higher-Support Necessity After Family-Chain Lift 90

## decision

Higher-support remains a named escape, but this round still does not justify support9+ expansion. The family-chain lift bridge clarified that the immediate blocker is lift-map refinement: source-form recognition and obstruction-preservation for support-growth witnesses.

Runtime table: `branch_4/90/runtime/higher_support_necessity_after_family_chain_lift_90.tsv`.
