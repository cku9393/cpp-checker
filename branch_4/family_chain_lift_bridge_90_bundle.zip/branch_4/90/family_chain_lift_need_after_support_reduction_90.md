# Family-Chain Lift Need After Support Reduction 90

## update after lift bridge

`family_chain_lift_bridge` has been attempted as a formal proof contract. The target family-chain package is ready and conditionally applicable, but the map from arbitrary support-growth witness to that package is still open.

The next target is `family_chain_lift_map_refinement`.

Runtime table: `branch_4/90/runtime/family_chain_lift_need_after_support_reduction_90.tsv`.
