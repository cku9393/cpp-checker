# Family Chain Support Absorption 90

## support-bound role

The family-chain package can be used as bounded family obstruction absorption. The family-chain lift bridge now proves target-package freshness and conditional applicability, but still requires lift-map refinement to show arbitrary support-growth witnesses enter that bounded language while preserving obstruction status.

## status

`partial_lift_target_ready_lift_map_open`.

Runtime table: `branch_4/90/runtime/family_chain_support_absorption_90.tsv`.
