# Support Bound Obligation Inventory 90

## summary after family-chain lift

- support-bound obligation count: `10`
- current verified obligations: `1`
- derivable-now obligations: `2`
- proof-sketch or partial-lift obligations: `5`
- blocked obligations: `2`

The selected support-bound statement is still not completed. Family-chain target freshness/applicability is no longer the blocker; the blocker is source-form recognition and obstruction-preserving lift-map correctness.

Runtime inventory: `branch_4/90/runtime/support_bound_obligation_inventory_90.tsv`.
