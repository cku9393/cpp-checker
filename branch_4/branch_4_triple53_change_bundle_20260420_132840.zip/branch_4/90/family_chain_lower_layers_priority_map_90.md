# Family Chain Lower Layers Priority Map 90

## purpose

This map compares the family-chain lower layers after the `triple_family_expansion_theorem_data_53` freshization round.

The conclusion is that outputs `52` and `53` are now current constructor/cache-backed, and output `55` is the next higher-value provenance target.

## current family-chain state

The top theorem object layer is already fresh current-runtime generated:

- `bounded family-chain theorem`
- `family-chain self verification`
- constructor: `build_current_family_chain_output_57_theorem_objects_`
- fallback hit: `0`

The remaining caveat is now below the triple-family layer.

## completed lower layer

`pair_expansion_aggregate_52`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_`
- pass2/pass3 cache loader: `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- regions: `28`
- raw / canonical / deduplicated: `501 / 501 / 182`
- survivors: `0 / 0 / 0`
- payload fingerprint: `6003:2005080337376028436`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- fallback hit: `0`

`triple_family_expansion_theorem_data_53`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_triple_family_expansion_theorem_data_53_from_pair52_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_triple_family_expansion_theorem_data_53_runtime_artifact_`
- regions: `35`
- raw / canonical / deduplicated: `2110 / 2110 / 282`
- survivors: `0 / 0 / 0`
- payload fingerprint: `11888:3562593626991170520`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream pair52 fallback hit: `0`
- fallback hit: `0`

## priority order

1. `quadruple_family_expansion_theorem_data_55`
2. `quintuple_family_expansion_theorem_data_57`
3. `sextuple_family_expansion_theorem_data_57`
4. `septuple_family_expansion_theorem_data_57`
5. `high_family_expansion_theorem_data_57`

## rationale

- The pair-expansion aggregate is no longer the blocker; it is generated/loaded from current runtime artifacts.
- Triple-family theorem data 53 is no longer the blocker; it is generated/loaded from current runtime artifacts with upstream pair52 fallback hit `0`.
- Quadruple layer already has a slow rebuild function and is foundational for deeper layers.
- Quintuple has a slow rebuild path and directly feeds unified family-chain counts.
- Sextuple/septuple/high-family are larger and should follow only after the lower layers are stabilized.

## decision

Do not spend the next round freshizing shell11/shell12 inventory-only rows. Keep them exposed as nonblocking perimeter rows and move the next freshization round to `quadruple_family_expansion_theorem_data_55`.
