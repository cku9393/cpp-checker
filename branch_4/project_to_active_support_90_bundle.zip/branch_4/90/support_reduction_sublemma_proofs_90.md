# Support Reduction Sublemma Proofs 90

## updated after project-to-active proof attempt

The selected operation `delete_redundant_support_coordinate` supplies a smaller-witness proof-ready skeleton with support-size decrease proved under the redundancy precondition. `project_to_active_support` now also supplies strict support-size decrease when active support is a strict subset.

Other support-reduction operations and counterexample-status preservation for active projection remain separate next-action candidates.

Runtime table: `branch_4/90/runtime/support_reduction_sublemma_proofs_90.tsv`.
