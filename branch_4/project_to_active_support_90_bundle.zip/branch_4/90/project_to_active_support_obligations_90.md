# Project To Active Support Obligations 90

## selected operation

`project_to_active_support`.

The obligations separate active-support definition, output construction, measure decrease, no-op classification, normal-form preservation, payload refinement, counterexample-status preservation, family-chain compatibility, and failure-to-escape routing.

Runtime inventory: `branch_4/90/runtime/project_to_active_support_obligations_90.tsv`.
