# Support Reduction Step Skeleton 90

## selected statement

`support_growth_partition`.

## status after project-to-active proof attempt

`partition_ready_delete_project_active_ready_remaining_operations_open`.

The support `>8` branch now separates:

- selected redundant-coordinate deletion case with support-size decrease proved under precondition;
- active-support projection case with support-size decrease proved when active support is a strict subset;
- other reducible support operation cases still open;
- recognized family-chain cases with well-defined lifted payloads and phase3 projection/canonical proof-ready skeletons;
- payload preserved and absorbed cases conditional on status preservation;
- operation-specific smaller-witness-open cases;
- named higher-support or non-family-chain escape cases.

The support-reduction theorem is still not complete because this proves only selected operation-specific precondition branches. Coordinate contraction, canonical motif compression, family-chain absorption reduction, arbitrary operation selection, and full counterexample-status preservation remain open.

Runtime skeleton: `branch_4/90/runtime/support_reduction_step_skeleton_90.tsv`.
