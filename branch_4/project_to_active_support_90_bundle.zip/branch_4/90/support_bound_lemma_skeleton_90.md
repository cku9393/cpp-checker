# Support-Bound Lemma Skeleton 90

## lemma

`support_minimal_counterexample_reduces_to_support8_or_escape`.

## status after project-to-active proof attempt

`proof_ready_skeleton_delete_project_active_ready_remaining_operations_open`.

The support-bound skeleton now has a more precise family-chain branch:

- support `<=8` remains handled by the proved limited bridge theorem;
- recognized family-chain source forms have well-defined lifted payloads and phase3 projection/canonical proof-ready skeletons;
- the redundant-coordinate deletion case has a selected operation proof-ready skeleton with measure decrease proved under precondition;
- the active-support projection case has support-size decrease proved when inactive support exists;
- valid preserved lifted payloads are conditionally absorbed by current bounded family-chain theorem;
- counterexample-status preservation and remaining operation-specific smaller-witness constructions remain open;
- preservation failure is a named escape/blocker.

This is not a full support8 sufficiency theorem and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/support_bound_lemma_skeleton_90.tsv`.
