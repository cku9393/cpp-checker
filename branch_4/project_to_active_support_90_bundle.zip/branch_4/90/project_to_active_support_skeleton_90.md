# Project To Active Support Skeleton 90

## operation lemma

`project_to_active_support_smaller_witness`.

## exact statement

Let `W` be a normal support `>8` witness with finite support set `S` and active support `A = active_support(W)`. If `A` is a strict subset of `S` and contains every coordinate used by the obstruction payload, counterexample certificate, canonical motif, frontier/shell/tail descriptors, and recognized family-chain lift fields, then `W_active = normalize(restrict(W,A))` is a smaller support witness candidate under the selected lexicographic support measure. If `A=S`, projection is a no-op and routes to the next operation. If projection loses required fields or fails normalization/status preservation, the case is a named blocker or higher-support escape after remaining operations are exhausted.

## final status

`partial_project_to_active_proved_escape_open`.

Active-support well-definedness, output well-definedness, strict measure decrease when inactive support exists, no-op classification, and failure naming are proved under the current operation contract. Normal-form preservation, payload-refinement transfer, canonical reindexing, family-chain source-form preservation, and counterexample-status preservation remain proof-sketch or blocked for arbitrary broader witnesses.

Runtime skeleton: `branch_4/90/runtime/project_to_active_support_skeleton_90.tsv`.
