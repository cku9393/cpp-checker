# Support Reduction Step Obligation Inventory 90

## updated after project-to-active proof attempt

The selected operation `delete_redundant_support_coordinate` has a first-class proof-ready skeleton. The second selected operation `project_to_active_support` now has active-support notation, operation semantics, smaller-witness construction, and a partial proof skeleton. Strict support-size decrease is proved when active support is a strict subset, but normal-form/payload/status preservation remains proof-sketch or blocked.

The support-reduction step remains incomplete because contraction, canonical motif compression, family-chain absorption reduction, arbitrary-witness operation selection, and higher-support closure are still open.

Runtime inventory: `branch_4/90/runtime/support_reduction_step_obligation_inventory_90.tsv`.
