# Proof System Reproduction Report 90

1. active workspace root
- `/Users/free_1/Library/Mobile Documents/iCloud~md~obsidian/Documents/cpp-checker`
2. active runtime data root
- `/Users/free_1/Library/Mobile Documents/iCloud~md~obsidian/Documents/cpp-checker/branch_4/90/runtime`
3. compile status
- release compile: verified
- LOCAL_TEST compile: verified
4. pass status
- pass1: `support8_authoritative_completion_locked`
- pass2: `support8_authoritative_completion_locked`
- pass3: `support8_authoritative_completion_locked`
5. current captured run status
- current reproducible classification: `support8_authoritative_completion_locked`
- archival classification: `support8_authoritative_completion_locked`
- lock achieved in captured run: `yes`
6. current counts before follow-up rerun
- required docs: `39` / `39` in the captured run
- required artifacts: `8` / `8`
7. provenance audit summary
- item count: `19`
- fresh current runtime generated: `16`
- current runtime validated imported data: `0`
- mixed: `0`
- archival only: `3`
- basis-only generation label: `fresh_current_runtime_generated` with promoted items `4`
- family-chain generation label: `fresh_current_runtime_generated` with promoted items `2`
- family-chain constructor: `build_current_family_chain_output_57_theorem_objects_` fallbackHit=`0`
8. pair-expansion aggregate 52
- final provenance label: `fresh_current_runtime_generated`
- constructor/cache path: `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- region count: `28`
- raw / canonical / deduplicated candidates: `501` / `501` / `182`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
9. triple-family theorem data 53
- final provenance label: `fresh_current_runtime_generated`
- constructor/cache path: `load_current_triple_family_expansion_theorem_data_53_runtime_artifact_`
- upstream pair52 fallback hit: `0`
- region count: `35`
- raw / canonical / deduplicated candidates: `2110` / `2110` / `282`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
10. quadruple-family theorem data 55
- final provenance label: `fresh_current_runtime_generated`
- constructor/cache path: `load_current_quadruple_family_expansion_theorem_data_55_runtime_artifact_`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- region count: `35`
- raw / canonical / deduplicated candidates: `3962` / `3962` / `294`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
11. quintuple-family theorem data 57
- final provenance label: `fresh_current_runtime_generated`
- constructor/cache path: `load_current_quintuple_family_expansion_theorem_data_57_runtime_artifact_`
- upstream quad55 fallback hit: `0`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- region count: `21`
- raw / canonical / deduplicated candidates: `3634` / `3634` / `294`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
12. first failing gate in captured run
- `none` with detail ``
13. next concrete action
- preserve the current support8 lock while moving the next provenance target to `sextuple_family_expansion_theorem_data_57`.
