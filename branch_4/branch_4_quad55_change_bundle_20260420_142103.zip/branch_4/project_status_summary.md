# 프로젝트 현황 정리

현재 상태를 보여주는 문서 묶음 인덱스는 `current_status_document_pack.md`다.

## 현재 current verified 상태

현재 workspace에서 직접 재현한 기준 코드는 `branch_4/90/full_dynamic_top_tree_engine_90.cpp`다.  
이 코드는 여전히 `This is NOT the complete BOJ solver`라고 명시하므로, 현재 verified 성공은 solver 완성이 아니라 support8 / shell15 / tail / completion-lock proof system의 current reproduction이다.

현재 verified 사실은 다음과 같다.

- release compile: verified
- LOCAL_TEST compile: verified
- active runtime root: `branch_4/90/runtime`
- required docs: `39 / 39`
- required artifacts: `8 / 8`
- LOCAL_TEST pass1: `support8_authoritative_completion_locked`
- LOCAL_TEST pass2: `support8_authoritative_completion_locked`
- LOCAL_TEST pass3: `support8_authoritative_completion_locked`
- current reproducible classification: `support8_authoritative_completion_locked`

## current bundle / imported provenance split

현재 top-level provenance inventory 기준 수치는 다음과 같다.

- provenance inventory item count: `19`
- fresh current runtime generated: `16`
- current runtime validated imported data: `0`
- mixed: `0`
- archival only: `3`

즉 현재 current verified top-level theorem / audit item은 모두 fresh current-runtime generated로 올라왔다.

- exact minimal basis size `96`
- exact n=5 basis-only theorem
- bounded n=6, c<=5 basis-only theorem
- bounded n=7, c<=3 basis-only theorem
- bounded family-chain theorem
- family-chain self verification
- antecedent plus twelve frontier
- support8 antecedent15 frontier
- support8 antecedent15 shell theorem
- support8 outside-bounded tail pattern theorem
- support8 tail obstruction chain theorem
- support8 authoritative completion lock
- artifact / document / rerun / freshness audit

다만 imported provenance 자체가 사라진 것은 아니다.  
현재 lower-frontier first-class inventory는 `23`개 row를 가지며, direct shell-theorem dependency subset `19`개는 freshized되었고 shell11/shell12 pair `4`개는 direct subset 밖의 inventory-only mixed row로 남아 있다.

이번 perimeter decision에서 이 `4`개 row는 모두 `keep_inventory_only_nonblocking`으로 확정했다.  
즉 freshize하지 않았고, top-level support8 lock blocker로도 취급하지 않는다.

family-chain lower imported layers 중 1순위였던 `pair_expansion_aggregate_52`는 이번 라운드에서 current constructor/cache-backed path로 승격했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_`
- pass2/pass3 cache loader: `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- row/object counts: regions `28`, raw `501`, canonical `501`, deduplicated `182`, survivors `0/0/0`
- payload fingerprint: `6003:2005080337376028436`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`

그 다음 target이었던 `triple_family_expansion_theorem_data_53`도 current constructor/cache-backed path로 승격했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_triple_family_expansion_theorem_data_53_from_pair52_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_triple_family_expansion_theorem_data_53_runtime_artifact_`
- row/object counts: regions `35`, raw `2110`, canonical `2110`, deduplicated `282`, survivors `0/0/0`
- payload fingerprint: `11888:3562593626991170520`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream pair52 fallback hit: `0`

이번 라운드 target이었던 `quadruple_family_expansion_theorem_data_55`도 current constructor/cache-backed path로 승격했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_quadruple_family_expansion_theorem_data_55_from_triple53_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_quadruple_family_expansion_theorem_data_55_runtime_artifact_`
- row/object counts: regions `35`, raw `3962`, canonical `3962`, deduplicated `294`, survivors `0/0/0`
- payload fingerprint: `15637:3406948456738223960`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`

다음 우선순위는 `quintuple_family_expansion_theorem_data_57`이다.

## 90 archival claim

`branch_4/90/` preserved bundle은 여전히 archival claim을 보존한다.

- archival classification: `support8_authoritative_completion_locked`
- preserved `_90.md` 노트들은 역사적/보존된 요약 노트로 유지된다
- archival only top-level item count: `3`

현재 workspace는 archival classification을 현재 rerun으로 재현했고, top-level theorem-data도 fresh current-runtime generated로 끌어올렸다.  
남은 caveat은 support8 slice 바깥 확장과 family-chain lower imported layer `57`을 어디까지 계속 freshize할지의 범위 문제다. Lower-frontier inventory-only shell11/shell12 pair `4`개는 visible perimeter row로 유지한다.

## 분류

- current reproducible classification: `support8_authoritative_completion_locked`
- archival classification: `support8_authoritative_completion_locked`
