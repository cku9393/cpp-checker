# Proof System Contract Memo 90

## baseline

- code baseline: `branch_4/90/full_dynamic_top_tree_engine_90.cpp`
- bundle role: support8 / shell15 / tail / completion-lock proof-system engine
- explicit non-goal: BOJ complete solver

## current bundle metadata

| item | current code fact | assessment |
| --- | --- | --- |
| solver identity | header says `This is NOT the complete BOJ solver` | current truth |
| non-LOCAL_TEST main | `int main() { return 0; }` | current truth |
| current bundle version | `90` | current truth |
| current bundle role | `support8 / shell15 / tail / completion-lock proof-system bundle` | current truth |
| current bundle source basename | `full_dynamic_top_tree_engine_90.cpp` | current truth |
| current bundle summary basename | `project_status_summary_90.md` | current bundle reference |

## imported closed-output provenance

| item | source in code | assessment |
| --- | --- | --- |
| provenance catalog | `imported_closed_output_provenance_catalog_()` | current truth |
| family-chain lower data | `family_chain_output_57` | imported theorem-data output retained as provenance |
| lower frontier ladder catalog | `support_plus_one_frontier_output_67` through `support8_shell14_frontier_output_79` | retained as imported provenance catalog; direct shell15 dependency subset is now current-generated |
| archival shell15 source | `support8_shell15_frontier_output_84` | retained as compatibility fallback / equality oracle, no longer authoritative current path |
| explicit source path retained | `/mnt/data/full_dynamic_top_tree_engine_84.cpp` for the `84` frontier source | provenance retained, not current bundle identity |

## required lists

| contract item | source function | count |
| --- | --- | --- |
| required docs | `required_support8_tail_doc_paths_83_()` | `39` |
| required artifacts | `required_support8_tail_artifact_paths_83_()` | `8` |

## audit gates

| gate | source function | pass condition |
| --- | --- | --- |
| artifact audit | `validate_artifact_completion_audit_stats_()` | all required artifacts exist, are nonempty, shell15 artifact set complete, tail artifact set complete |
| document audit | `validate_document_completion_audit_stats_()` | all required docs are nonempty and core summary / shell theorem / tail pattern / artifact notes / bridge note are ready |
| rerun audit | `validate_rerun_completion_audit_stats_()` | local-test binary exists, current run or current stamp matches current binary, release binary exists and release stamp matches current binary |
| audit freshness | `validate_support8_audit_freshness_stats_()` | current artifact/doc/rerun audit fingerprints all match current filesystem / stamps |
| tail obstruction chain | `validate_support8_tail_obstruction_chain_theorem_data_()` | shell15 theorem + tail pattern + artifact audit + document audit + rerun audit + freshness all pass |
| completion lock | `validate_support8_authoritative_completion_lock_data_()` | shell15 frontier + shell15 scope + tail pattern + tail chain + artifact audit + document audit + rerun audit + freshness + stale audit eliminated + local test verified + release compile verified |

## provenance outputs

| output | path | role |
| --- | --- | --- |
| top-level inventory tsv | `branch_4/90/runtime/theorem_data_provenance_inventory_90.tsv` | machine-readable top-level theorem/audit validation split |
| lower-frontier inventory tsv | `branch_4/90/runtime/lower_frontier_ladder_inventory_90.tsv` | machine-readable first-class lower-frontier inventory |
| lower-frontier generation audit | `branch_4/90/runtime/lower_frontier_ladder_generation_audit_90.tsv` | direct shell-theorem dependency subset generation/cache audit |
| shell-theorem generation audit | `branch_4/90/runtime/support8_antecedent15_shell_theorem_generation_audit_90.tsv` | shell theorem freshization status over the lower ladder |
| inventory-only decision audit | `branch_4/90/runtime/lower_frontier_inventory_only_decision_90.tsv` | shell11/shell12 inventory-only perimeter decision |
| family-chain lower-layer inventory | `branch_4/90/runtime/family_chain_lower_layers_inventory_90.tsv` | next family-chain lower imported layer priority map |
| pair-expansion aggregate 52 audit | `branch_4/90/runtime/pair_expansion_aggregate_52_generation_audit_90.tsv` | current constructor/cache-backed output 52 audit |
| pair-expansion aggregate 52 payload | `branch_4/90/runtime/pair_expansion_aggregate_52_payload_90.tsv` | 28-region single/pair bounded expansion payload |
| triple-family theorem data 53 audit | `branch_4/90/runtime/triple_family_expansion_theorem_data_53_generation_audit_90.tsv` | current constructor/cache-backed output 53 audit |
| triple-family theorem data 53 payload | `branch_4/90/runtime/triple_family_expansion_theorem_data_53_payload_90.tsv` | 35-region triple-family bounded expansion payload |
| quadruple-family theorem data 55 audit | `branch_4/90/runtime/quadruple_family_expansion_theorem_data_55_generation_audit_90.tsv` | current constructor/cache-backed output 55 audit |
| quadruple-family theorem data 55 payload | `branch_4/90/runtime/quadruple_family_expansion_theorem_data_55_payload_90.tsv` | 35-region quadruple-family bounded expansion payload |
| provenance summary tsv | `branch_4/90/runtime/provenance_audit_fingerprint_90.tsv` | machine-readable counts and current bundle metadata |
| runtime audit report | `branch_4/90/runtime/provenance_audit_report_90.md` | short current-runtime provenance report |
| archival inventory note | `branch_4/90/theorem_data_provenance_inventory_90.md` | preserved markdown view of the current inventory |

## current verified recovery state

- release compile: verified
- LOCAL_TEST compile: verified
- pass1: `support8_authoritative_completion_locked`
- pass2: `support8_authoritative_completion_locked`
- pass3: `support8_authoritative_completion_locked`
- current runtime root: `branch_4/90/runtime`
- required docs: `39 / 39`
- required artifacts: `8 / 8`

## provenance snapshot

- top-level item count: `19`
- top-level fresh current runtime generated: `16`
- top-level current runtime validated imported data: `0`
- top-level mixed: `0`
- top-level archival only: `3`
- lower-frontier first-class inventory row count: `23`
- lower-frontier direct dependency subset count: `19`
- lower-frontier direct dependency freshized count: `19`
- lower-frontier inventory-only mixed rows: shell11/shell12 pair `4`
- inventory-only decision: `freshize_now=0`, `keep_inventory_only_nonblocking=4`, `defer_after_family_chain=0`
- pair-expansion aggregate 52: `fresh_current_runtime_generated`
- pair-expansion aggregate 52 constructor/cache: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_` -> `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- triple-family theorem data 53: `fresh_current_runtime_generated`
- triple-family theorem data 53 constructor/cache: `build_current_triple_family_expansion_theorem_data_53_from_pair52_ready_family_scan_` -> `load_current_triple_family_expansion_theorem_data_53_runtime_artifact_`
- quadruple-family theorem data 55: `fresh_current_runtime_generated`
- quadruple-family theorem data 55 constructor/cache: `build_current_quadruple_family_expansion_theorem_data_55_from_triple53_ready_family_scan_` -> `load_current_quadruple_family_expansion_theorem_data_55_runtime_artifact_`
- family-chain lower-layer status: fresh `3`, imported lower-layer `4`
- next priority: `quintuple_family_expansion_theorem_data_57`

## immediate implication

- support8 lock recovery, lower-frontier direct dependency freshization, shell theorem freshization, tail-chain freshization, and completion-lock freshization are now current runtime facts for the support8 slice.
- the audit order and required counts were not weakened.
- the lower-frontier inventory-only shell11/shell12 rows are now explicitly retained as nonblocking perimeter rows.
- the remaining limitation is no longer a top-level mixed theorem item, pair-expansion output `52`, triple-family output `53`, or quadruple-family output `55`; it is the deeper family-chain lower imported layer caveat starting at `quintuple_family_expansion_theorem_data_57`.
