# Tail Monotonicity Bridge Obligation Inventory 90

## summary

- tail bridge obligation count: `10`
- `current_verified`: `2`
- `derivable_now`: `1`
- `proof_sketch_ready`: `3`
- `needs_new_bridge_lemma`: `3`
- `needs_shell16_attempt`: `1`
- `needs_shell16_preflight`: `0`

## current result

Checked tail absorption is proved under the current support8 shell15/tail scope. The full absorption step for extension witnesses is not proved. The bridge therefore routes the first unchecked extension witness to `shell16_escape`, and the shell16 preflight contract now defines how that escape must be attempted without theorem promotion.

## next blocker

The next blocker is `shell16_attempt`. The proof-side alternative is `prove_or_refine_tail_absorption_step`, but current runtime evidence does not justify treating arbitrary extension tails as absorbed.
