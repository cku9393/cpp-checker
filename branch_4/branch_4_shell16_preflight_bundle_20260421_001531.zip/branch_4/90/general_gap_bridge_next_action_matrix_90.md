# General Gap Bridge Next Action Matrix 90

## recommendation

Top recommendation: `shell16_attempt`.

Second recommendation: `prove_or_refine_tail_absorption_step`.

Third recommendation: `limited_bridge_theorem_proof_attempt`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `shell16_attempt` | 84 | 88 | 82 | 72 | 92 | 92 | 1 | `shell16_attempt` |
| `prove_or_refine_tail_absorption_step` | 62 | 90 | 65 | 74 | 78 | 84 | 2 | `prove_or_refine_tail_absorption_step` |
| `limited_bridge_theorem_proof_attempt` | 68 | 90 | 65 | 70 | 76 | 80 | 3 | `limited_bridge_theorem_proof_attempt` |
| `formalize_support_bound_lemma` | 42 | 90 | 80 | 80 | 44 | 68 | 4 | `formalize_support_bound_lemma` |
| `boj_problem_bridge_formalization` | 58 | 65 | 50 | 50 | 60 | 62 | 5 | `boj_problem_bridge_formalization` |

## rationale

`shell16_preflight_refactor` is complete as a contract round: scope, dependency map, artifact contract, document contract, audit contract, feasibility, guardrail, and attempt protocol are now first-class. It did not run shell16 and did not claim survivor counts. Therefore the next exact target is `shell16_attempt`.

`prove_or_refine_tail_absorption_step` remains the proof-side alternative to running shell16. `limited_bridge_theorem_proof_attempt` should wait until the shell16/absorption fork is resolved or explicitly assumed.
