# Minimal Counterexample Reduction Sublemma Proofs 90

## proved under current scope

`existence_of_minimal_witness`: Under the selected limited statement, the witness class is finite/current-admissible and the selected measure is lexicographic over well-founded coordinates. Therefore any nonempty witness set has a minimal element.

`family_chain_capture`: For bounded family-chain witnesses in the current language, the bounded family-chain theorem and all seven lower layers are current verified. Thus a bounded family-chain component is captured by the fresh family-chain package.

`finite_package_contradiction`: If a normalized witness is captured by the current finite package, it contradicts the support8 completion lock and survivor-free finite audits.

`escape_obligations_are_named_and_disjoint`: The escape interface is a disjoint taxonomy by trigger condition: tail, shell16, higher-support, BOJ constructivity, archive independence, or current finite scope.

## proof-sketch only

Normalization, support escape, shell escape, tail absorption/extension routing, frontier capture, and obstruction-chain capture have proof sketches but still depend on explicit bridge lemmas or shell16 preflight.

## blocked

No sublemma remains blocked inside the minimal-reduction skeleton after the tail bridge reclassification. The shell16 preflight contract is now ready, so the external next blocker is `shell16_attempt`.
