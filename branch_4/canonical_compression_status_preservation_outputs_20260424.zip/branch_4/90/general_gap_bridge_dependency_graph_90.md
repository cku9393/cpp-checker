# General Gap Bridge Dependency Graph 90

## status after canonical-compression status round

The dependency graph now records project-to-active, coordinate-contraction, and canonical-compression status as proof-ready but not proved. Support-bound justification still depends on operation-specific status proofs, with family-chain absorption status/refutation next.

Runtime graph: `branch_4/90/runtime/general_gap_bridge_dependency_graph_90.tsv`.
