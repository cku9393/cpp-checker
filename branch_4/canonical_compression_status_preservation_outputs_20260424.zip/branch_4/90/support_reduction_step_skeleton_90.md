# Support Reduction Step Skeleton 90

## selected statement

`support_growth_partition`

## status after canonical-compression status round

`partition_ready_project_contraction_compression_status_proof_ready_remaining_operations_open`.

The support `>8` branch now separates:

- delete-redundant reduced case under redundancy precondition;
- project-to-active measure-decrease case with status proof-ready/locality-open skeleton;
- coordinate-contraction measure-decrease case with status proof-ready/congruence-open skeleton;
- canonical-compression measure-decrease case with status proof-ready/congruence-open skeleton;
- family-chain absorption measure/status-open case;
- downstream frontier/tail capture after valid support `<=8` reduction;
- named operation blockers;
- irreducible higher-support escape only after operation proofs close.

The project-to-active, coordinate-contraction, and canonical-compression status branches are not proved, but they are no longer opaque blockers. No support9+ scan was run.

Runtime skeleton: `branch_4/90/runtime/support_reduction_step_skeleton_90.tsv`.
