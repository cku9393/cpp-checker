# Support-Bound Lemma Skeleton 90

## lemma

`support_minimal_counterexample_reduces_to_support8_or_escape`

## status after canonical-compression status round

`proof_ready_skeleton_project_contraction_compression_status_proof_ready_remaining_operations_open`.

The support-bound skeleton now has:

- support8 handled by the limited bridge theorem;
- delete-redundant selected case ready under redundancy precondition;
- project-to-active measure decrease plus status proof-ready/locality-open skeleton;
- coordinate-contraction measure decrease plus status proof-ready/congruence-open skeleton;
- canonical-compression lexicographic measure decrease plus status proof-ready/congruence-open skeleton;
- remaining family-chain absorption status/refutation and residual measure blockers;
- deferred higher-support bound only if true irreducible support `>8` escape remains after operation proofs close.

This is not support-bound completion, not a project-to-active proof completion, not a coordinate-contraction proof completion, not a canonical-compression proof completion, and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/support_bound_lemma_skeleton_90.tsv`.
