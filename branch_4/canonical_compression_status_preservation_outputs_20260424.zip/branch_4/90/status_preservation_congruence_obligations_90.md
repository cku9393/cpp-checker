# Status Preservation Congruence Obligations 90

## status after canonical-compression status round

Project-to-active status is `proof_ready_skeleton_project_to_active_status_locality_open`. Coordinate contraction status is `proof_ready_skeleton_contract_equivalent_status_congruence_open`. Canonical compression status is now `proof_ready_skeleton_canonical_compression_status_congruence_open`. Family-chain absorption remains the direct operation-proof-open blocker.

Runtime inventory: `branch_4/90/runtime/status_preservation_congruence_obligations_90.tsv`.
