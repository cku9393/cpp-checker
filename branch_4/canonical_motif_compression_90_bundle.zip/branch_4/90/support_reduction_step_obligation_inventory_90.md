# Support Reduction Step Obligation Inventory 90

## updated after canonical-motif-compression proof attempt

The selected operation `delete_redundant_support_coordinate` has a first-class proof-ready skeleton. `project_to_active_support` has active-support notation, operation semantics, smaller-witness construction, and a partial proof skeleton. `contract_equivalent_support_coordinates` has equivalent-coordinate notation, quotient semantics, smaller-witness construction, and a partial proof skeleton. `canonical_motif_compression` now has canonical motif notation, compression semantics, smaller-witness construction, and a partial proof skeleton. Strict measure decrease is proved for redundant deletion, active-support strict subset, nontrivial equivalence-class quotient, and accepted canonical motif compression preconditions, but normal-form/payload/status preservation remains proof-sketch or blocked.

The support-reduction step remains incomplete because counterexample-status congruence, family-chain absorption reduction, arbitrary-witness operation selection, and higher-support closure are still open.

Runtime inventory: `branch_4/90/runtime/support_reduction_step_obligation_inventory_90.tsv`.
