# Support Reduction Sublemma Proofs 90

## updated after canonical-motif-compression proof attempt

The selected operation `delete_redundant_support_coordinate` supplies a smaller-witness proof-ready skeleton with support-size decrease proved under the redundancy precondition. `project_to_active_support` supplies strict support-size decrease when active support is a strict subset. `contract_equivalent_support_coordinates` supplies strict support-size decrease when an accepted equivalence relation has a nontrivial class. `canonical_motif_compression` supplies strict lexicographic decrease when an accepted compression lowers support size or, with support fixed, canonical motif rank.

Family-chain absorption and counterexample-status preservation for active projection, contraction, and compression remain separate next-action candidates.

Runtime table: `branch_4/90/runtime/support_reduction_sublemma_proofs_90.tsv`.
