# General Gap Bridge Lemma Candidates 90

## next candidate

First candidate after this round: `prove_next_support_reduction_operation_sublemma`.

The selected redundant-coordinate deletion, active-support projection, coordinate-contraction, and canonical-motif-compression operations now have first-class skeletons under explicit preconditions. Counterexample-status preservation and family-chain absorption construction remain open. The next candidate is the next support-reduction operation sublemma path.

Runtime candidates: `branch_4/90/runtime/general_gap_bridge_lemma_candidates_90.tsv`.
