# Family-Chain Lift Phase3 Skeleton 90

## lemma

`layer_projection_payload_preservation_and_canonical_lift_soundness`.

## exact statement

For recognized family-chain source-form witnesses, the phase3 target is restricted to layer projection payload preservation and canonical lift soundness. The current artifacts prove that projection layers are declared and well-defined under the recognized-source contract. They make layerwise semantic preservation and canonical lift commutation proof-ready, but do not prove them. The selected redundant-coordinate deletion operation covers one smaller-witness case under its redundancy precondition. `project_to_active_support` covers the inactive-support strict-subset measure-decrease case under active-support containment. `contract_equivalent_support_coordinates` covers the nontrivial equivalent-coordinate quotient measure-decrease case under congruence preconditions. These do not close all phase3 operation cases.

## selected target

- `phase3_needed_layer_projection_payload_preservation`
- `phase3_needed_canonical_lift_soundness`

## proof outline

1. Start from the phase2 source-target correspondence table.
2. Split the source payload by family-chain layer.
3. Check that every selected layer has a target projection row.
4. Isolate the layer-specific payload preservation sublemma for each layer.
5. Compare source canonicalization then lift with lift then target canonicalization.
6. Route canonical mismatch to canonical blocker, smaller-witness trigger, or named escape.
7. Leave counterexample-status preservation as a later semantic theorem.
8. Use `delete_redundant_support_coordinate` when the redundancy precondition holds.
9. Use `project_to_active_support` when active support is a strict subset and required fields are contained in it.
10. Use `contract_equivalent_support_coordinates` when a nontrivial accepted equivalence class can be quotient-contracted.
11. Leave remaining operation-specific smaller-witness constructions to the next support-reduction operation proof.

## final status

`partial_phase3_delete_project_contraction_compression_ready_remaining_operations_open`.

This is not a full family-chain lift proof and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/family_chain_lift_phase3_skeleton_90.tsv`.
