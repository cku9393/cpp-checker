# Family-Chain Operation-Specific Smaller Witness 90

## purpose

This document connects the smaller-witness branch to existing support-reduction operations.

## result

No new operation is introduced. The selected `delete_redundant_support_coordinate` operation has a proof-ready skeleton with support-size decrease and conditional counterexample transfer under the redundancy precondition. `project_to_active_support` has active-support notation, semantics, smaller-witness construction, and a partial proof skeleton with support-size decrease proved under the strict-active-subset precondition. `contract_equivalent_support_coordinates` has equivalent-coordinate notation, quotient semantics, smaller-witness construction, and a partial proof skeleton with support-size decrease proved under the nontrivial-class precondition. `canonical_motif_compression` now has canonical motif notation, compression semantics, smaller-witness construction, and a partial proof skeleton with lexicographic measure decrease proved under the accepted-compression precondition.

Remaining smaller-witness branches are still operation-specific and should be handled by `prove_next_support_reduction_operation_sublemma` next.

Runtime table: `branch_4/90/runtime/family_chain_operation_specific_smaller_witness_90.tsv`.
