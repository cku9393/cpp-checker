# General Gap Bridge Next Action Matrix 90

## recommendation after canonical-motif-compression proof attempt

Top recommendation: `prove_next_support_reduction_operation_sublemma`.

Second recommendation: `higher_support_necessity_recheck`.

Third recommendation: `limited_to_broader_generalization_plan`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `prove_next_support_reduction_operation_sublemma` | 80 | 86 | 68 | 66 | 88 | 84 | 1 | `prove_next_support_reduction_operation_sublemma` |
| `higher_support_necessity_recheck` | 76 | 84 | 58 | 64 | 88 | 80 | 2 | `higher_support_necessity_recheck` |
| `limited_to_broader_generalization_plan` | 71 | 80 | 55 | 60 | 83 | 75 | 3 | `limited_to_broader_generalization_plan` |
| `support_bound_completion` | 67 | 78 | 62 | 68 | 79 | 71 | 4 | `support_bound_completion` |
| `family_chain_lift_phase4_if_needed` | 60 | 76 | 70 | 75 | 74 | 67 | 5 | `family_chain_lift_phase4_if_needed` |
| `boj_problem_bridge_formalization` | 42 | 60 | 50 | 50 | 58 | 52 | 6 | `boj_problem_bridge_formalization` |

## rationale

The selected redundant-coordinate deletion, project-to-active, coordinate-contraction, and canonical-compression routes now have first-class skeletons with strict support or lexicographic measure decrease under explicit preconditions. The most concrete remaining blocker is still operation-specific preservation/construction, now especially `family_chain_absorption_reduction` and counterexample-status preservation.

This remains a bridge/planning state, not a full general theorem.
