# Family-Chain Lift Skeleton 90

## lemma

`family_chain_lift_or_higher_support_escape`, refined by `obstruction_preservation_or_higher_support_escape`.

## status after coordinate-contraction proof attempt

`partial_lift_delete_project_contraction_ready_remaining_operations_open`.

The family-chain lift now has:

- source-form recognition and refined target map for recognized sources;
- well-defined source/target obstruction payload semantics;
- conditional bounded family-chain absorption after valid preserved payload;
- selected `delete_redundant_support_coordinate` smaller-witness route under redundancy precondition;
- selected `project_to_active_support` smaller-witness route under active-support strict-subset precondition;
- selected `contract_equivalent_support_coordinates` smaller-witness route under nontrivial accepted-equivalence precondition;
- named escape routing for preservation failure.

Still open:

- remaining operation-specific smaller-witness constructions for canonical compression and family-chain absorption;
- counterexample-status preservation or smaller-witness construction;
- arbitrary support-growth lift correctness.

This is not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/family_chain_lift_skeleton_90.tsv`.
