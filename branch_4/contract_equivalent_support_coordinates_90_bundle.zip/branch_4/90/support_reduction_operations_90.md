# Support Reduction Operations 90

## operation inventory

The support reduction attempt defines eight candidate operations. None is promoted as an unrestricted support-reduction theorem. The currently strongest result is an operation/escape interface plus two operation proof skeletons:

- `delete_redundant_support_coordinate` is selected and has measure decrease plus conditional counterexample transfer under the redundancy precondition;
- `project_to_active_support` now has active-support notation, operation semantics, smaller-witness construction, obligations, sublemma proof attempts, and a partial proof skeleton;
- `contract_equivalent_support_coordinates` now has equivalent-coordinate notation, quotient/contraction semantics, smaller-witness construction, obligations, proof attempts, and a partial proof skeleton;
- remaining declared reduction operations are proof-ready only under explicit preconditions;
- `family_chain_absorption_reduction` is now routed through the phase3 projection/canonical proof-ready contract and remains blocked by operation-specific smaller-witness construction;
- irreducible support `>8` cases are routed to `higher_support_escape`.

Runtime table: `branch_4/90/runtime/support_reduction_operations_90.tsv`.
