# General Gap Bridge Next Action Matrix 90

## recommendation after coordinate-contraction proof attempt

Top recommendation: `prove_next_support_reduction_operation_sublemma`.

Second recommendation: `higher_support_necessity_recheck`.

Third recommendation: `limited_to_broader_generalization_plan`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `prove_next_support_reduction_operation_sublemma` | 82 | 87 | 70 | 67 | 90 | 85 | 1 | `prove_next_support_reduction_operation_sublemma` |
| `higher_support_necessity_recheck` | 74 | 84 | 58 | 64 | 88 | 80 | 2 | `higher_support_necessity_recheck` |
| `limited_to_broader_generalization_plan` | 69 | 80 | 55 | 60 | 82 | 74 | 3 | `limited_to_broader_generalization_plan` |
| `support_bound_completion` | 65 | 78 | 62 | 68 | 78 | 70 | 4 | `support_bound_completion` |
| `family_chain_lift_phase4_if_needed` | 60 | 76 | 70 | 75 | 74 | 67 | 5 | `family_chain_lift_phase4_if_needed` |
| `boj_problem_bridge_formalization` | 42 | 60 | 50 | 50 | 58 | 52 | 6 | `boj_problem_bridge_formalization` |

## rationale

The selected redundant-coordinate deletion, project-to-active, and coordinate-contraction routes now have first-class skeletons with strict support-size decrease under explicit preconditions. The most concrete remaining blocker is still operation-specific preservation/construction, now especially `canonical_motif_compression`, family-chain absorption reduction, and counterexample-status preservation.

This remains a bridge/planning state, not a full general theorem.
