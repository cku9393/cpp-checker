# Contract Equivalent Support Coordinates Obligations 90

## purpose

This inventory records the proof obligations for `contract_equivalent_support_coordinates`.

The current round proves the finite quotient and strict support-size decrease under a nontrivial accepted equivalence class. Payload/canonical preservation is proof-sketch-ready. Counterexample-status congruence remains the main blocker.

Runtime inventory: `branch_4/90/runtime/contract_equivalent_support_coordinates_obligations_90.tsv`.
