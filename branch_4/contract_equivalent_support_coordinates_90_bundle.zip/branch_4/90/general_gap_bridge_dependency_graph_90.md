# General Gap Bridge Dependency Graph 90

## updated dependency focus

The graph now routes the family-chain branch through phase2 payload refinement:

`source_form_recognizer` -> `refined_lift_map` -> `payload_semantics` -> `phase2_relation/correspondence` -> `phase3_projection/canonical` -> `counterexample_status_semantics` -> `operation_specific_smaller_witness`.

The graph now includes the selected `delete_redundant_support_coordinate` operation skeleton. The remaining dependency is the next operation-specific smaller-witness construction and preservation, with higher-support escape still open after that.

Runtime graph: `branch_4/90/runtime/general_gap_bridge_dependency_graph_90.tsv`.
