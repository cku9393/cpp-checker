# Higher-Support Escape Interface 90

## status after coordinate-contraction proof attempt

`higher_support_recheck_deferred_until_remaining_operation_sublemmas`.

The interface now distinguishes:

- recognized family-chain payload-preservation-open cases;
- phase2 layerwise refinement proof-open cases;
- phase3 projection/canonical proof-ready but not proved cases;
- selected redundant-coordinate smaller-witness case under precondition;
- active-support projection case under strict-active-subset precondition;
- coordinate-contraction quotient case under nontrivial accepted-equivalence precondition;
- remaining smaller-witness operation-construction blockers;
- payload mismatch/canonicalization blockers;
- status-preservation blockers;
- support-reduction operation blockers;
- genuinely unrecognized/higher-support cases.

No support9+ scan is performed or implied.

Runtime interface: `branch_4/90/runtime/higher_support_escape_interface_90.tsv`.
