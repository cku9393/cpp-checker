# Contract Equivalent Support Coordinates Sublemma Proofs 90

## proof attempts

The current proof attempt proves the finite quotient construction and strict support-size decrease under a nontrivial equivalence class. It does not prove unconditional payload/counterexample preservation.

Runtime table: `branch_4/90/runtime/contract_equivalent_support_coordinates_sublemma_proofs_90.tsv`.
