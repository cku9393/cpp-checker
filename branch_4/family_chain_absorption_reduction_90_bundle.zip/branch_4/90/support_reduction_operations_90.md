# Support Reduction Operations 90

## operation inventory

The support reduction attempt defines eight candidate operations. None is promoted as an unrestricted support-reduction theorem. The currently strongest result is an operation/escape interface plus five operation proof skeletons:

- `delete_redundant_support_coordinate` has measure decrease plus conditional counterexample transfer under the redundancy precondition;
- `project_to_active_support` has active-support notation, operation semantics, smaller-witness construction, obligations, sublemma proof attempts, and a partial proof skeleton;
- `contract_equivalent_support_coordinates` has equivalent-coordinate notation, quotient/contraction semantics, smaller-witness construction, obligations, proof attempts, and a partial proof skeleton;
- `canonical_motif_compression` has canonical motif notation, compression semantics, smaller-witness construction, obligations, proof attempts, and a partial proof skeleton;
- `family_chain_absorption_reduction` now has absorption notation, operation semantics, contradiction-or-smaller-witness construction, obligations, proof attempts, and a partial proof skeleton.

The active projection, coordinate contraction, canonical compression, and family-chain absorption routes still have counterexample-status preservation or residual measure blockers. Irreducible support `>8` cases remain routed to the named higher-support/status escape interface.

Runtime table: `branch_4/90/runtime/support_reduction_operations_90.tsv`.
