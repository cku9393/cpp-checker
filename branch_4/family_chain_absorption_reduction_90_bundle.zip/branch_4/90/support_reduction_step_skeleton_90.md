# Support Reduction Step Skeleton 90

## selected statement

`support_growth_partition`.

## status after family-chain-absorption proof attempt

`partition_ready_delete_project_contraction_compression_absorption_ready_status_open`.

The support `>8` branch now separates:

- selected redundant-coordinate deletion case with support-size decrease proved under precondition;
- active-support projection case with support-size decrease proved when active support is a strict subset;
- equivalent-coordinate contraction case with support-size decrease proved when an accepted equivalence class is nontrivial;
- canonical motif compression case with lexicographic measure decrease under accepted compression;
- family-chain absorption case with trigger, target package, contradiction branch, residual smaller-witness candidate, and named escape classification;
- status-preservation-open cases for active projection, contraction, compression, and absorption;
- residual absorption measure-decrease-open case;
- frontier/tail captured cases after valid support `<=8` reduction;
- named higher-support or non-family-chain escape cases.

The support-reduction theorem is still not complete. This proves only selected operation-specific precondition branches and formalizes the absorption route. Full counterexample-status congruence, residual absorption measure decrease, arbitrary operation selection completeness, and higher-support closure remain open.

Runtime skeleton: `branch_4/90/runtime/support_reduction_step_skeleton_90.tsv`.
