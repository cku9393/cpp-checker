# Family-Chain Absorption Reduction Skeleton 90

## operation lemma

`family_chain_absorption_reduction_or_named_escape`

## exact statement

If a normal support>8 recognized family-chain witness satisfies the family-chain absorption trigger, then the matched component either yields a contradiction by the bounded family-chain theorem, yields a residual smaller-witness candidate after absorption, or is routed to a named measure/status/applicability blocker or higher-support escape. The contradiction and smaller-witness branches are distinct.

## assumptions

- current support8 lock remains authoritative;
- family-chain lower layers are `7/7 fresh`, imported `0`;
- limited bridge theorem remains `limited_bridge_theorem_proved_under_current_scope`;
- phase2/phase3 payload and canonical skeletons remain proof-ready, not completed;
- prior delete/project/contraction/compression operations remain one-operation skeletons, not an all-operation proof.

## status

`partial_absorption_reduction_proved_escape_open`

The trigger, target package availability, target self-verification, and failure classification are current-scope proved. The theorem-applicability/contradiction branch is proof-sketch ready under payload/status assumptions. The residual smaller-witness branch remains blocked by measure decrease and counterexample-status preservation.

Runtime table: `branch_4/90/runtime/family_chain_absorption_reduction_skeleton_90.tsv`.
