# Family-Chain Lift Phase3 Skeleton 90

## lemma

`layer_projection_payload_preservation_and_canonical_lift_soundness`.

## exact statement

For recognized family-chain source-form witnesses, the phase3 target is restricted to layer projection payload preservation and canonical lift soundness. The current artifacts prove that projection layers are declared and well-defined under the recognized-source contract. They make layerwise semantic preservation and canonical lift commutation proof-ready, but do not prove them.

The operation-sublemma track now provides first-class routes for redundant-coordinate deletion, active-support projection, equivalent-coordinate contraction, canonical motif compression, and family-chain absorption reduction. These routes remain operation-specific and do not close arbitrary counterexample-status preservation.

## selected target

- `phase3_needed_layer_projection_payload_preservation`
- `phase3_needed_canonical_lift_soundness`

## proof outline

1. Start from the phase2 source-target correspondence table.
2. Split the source payload by family-chain layer.
3. Check that every selected layer has a target projection row.
4. Isolate the layer-specific payload preservation sublemma for each layer.
5. Compare source canonicalization then lift with lift then target canonicalization.
6. Route canonical mismatch to canonical blocker, smaller-witness trigger, or named escape.
7. Leave counterexample-status preservation as a later semantic theorem.
8. Use `delete_redundant_support_coordinate` when the redundancy precondition holds.
9. Use `project_to_active_support` when active support is a strict subset and required fields are contained in it.
10. Use `contract_equivalent_support_coordinates` when a nontrivial accepted equivalence class can be quotient-contracted.
11. Use `canonical_motif_compression` when an accepted compression lowers support size or canonical motif rank.
12. Use `family_chain_absorption_reduction` when a recognized family-chain absorption trigger yields a bounded target contradiction or residual smaller-witness candidate.
13. Leave status-preservation congruence and residual absorption measure as the next blockers.

## final status

`partial_phase3_delete_project_contraction_compression_absorption_ready_status_open`.

This is not a full family-chain lift proof and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/family_chain_lift_phase3_skeleton_90.tsv`.
