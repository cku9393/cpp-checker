# Support-Bound Lemma Skeleton 90

## lemma

`support_minimal_counterexample_reduces_to_support8_or_escape`.

## status after family-chain-absorption proof attempt

`proof_ready_skeleton_delete_project_contraction_compression_absorption_ready_status_open`.

The support-bound skeleton now has a more precise family-chain branch:

- support `<=8` remains handled by the proved limited bridge theorem;
- recognized family-chain source forms have well-defined lifted payloads and phase3 projection/canonical proof-ready skeletons;
- redundant-coordinate deletion, active-support projection, coordinate contraction, and canonical motif compression each have operation-specific skeletons under explicit preconditions;
- family-chain absorption now has a trigger, target package, contradiction branch, residual smaller-witness candidate, and named escape classification;
- valid preserved lifted payloads are still only conditionally absorbed by the bounded family-chain theorem;
- counterexample-status preservation/reduction/refutation and residual absorption measure decrease remain open;
- preservation failure is a named escape/blocker.

This is not a full support8 sufficiency theorem and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/support_bound_lemma_skeleton_90.tsv`.
