# Support Reduction Sublemma Proofs 90

## proof attempt result

The current proof attempt proves only the conditional infrastructure needed by a future concrete support reduction operation:

- if a strict support-tuple decrease operation is supplied, iteration terminates;
- if the process reaches support `<=8`, the proved limited bridge theorem applies;
- if a support `>8` witness is irreducible under the declared operations and no family lift applies, it is a named `higher_support_escape`.

The concrete preservation proof for all support-reduction operations is not complete. The family-chain branch is blocked by `family_chain_support_lift`.

Runtime proofs: `branch_4/90/runtime/support_reduction_sublemma_proofs_90.tsv`.
