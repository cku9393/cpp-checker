# Higher-Support Necessity Recheck After Support Reduction 90

## decision

Higher-support remains a named open escape, but this round does not justify support9+ expansion. The next better target is `family_chain_lift_bridge`, because the support-growth partition shows a concrete lift blocker before any scan should be opened.

Runtime table: `branch_4/90/runtime/higher_support_necessity_recheck_after_support_reduction_90.tsv`.
