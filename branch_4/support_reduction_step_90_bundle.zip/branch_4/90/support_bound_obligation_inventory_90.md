# Support Bound Obligation Inventory 90

## summary

- support-bound obligation count: `10`
- current verified obligations: `1`
- derivable-now obligations: `2`
- proof-sketch or partition-ready obligations: `5`
- blocked obligations: `2`

The selected support-bound statement is still not completed. The support-reduction round refined `support_reduction_step` into a first-class partition and proved only conditional infrastructure: support8 re-entry and termination under strict decrease. The main blocker is now `family_chain_support_lift`, with operation-specific support-reduction preservation still required.

Runtime inventory: `branch_4/90/runtime/support_bound_obligation_inventory_90.tsv`.
