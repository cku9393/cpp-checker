# Higher-Support Escape Interface 90

## summary

Support `>8` non-reduced witnesses remain named as `higher_support_escape`; the support-reduction attempt refined when that escape is used.

Status:

`higher_support_escape_interface_partition_ready_open`.

This blocks broader and full general theorem statements, but it does not block the already proved selected limited bridge theorem. The next proof-side target is `family_chain_lift_bridge`, not support9+ expansion.

Runtime table: `branch_4/90/runtime/higher_support_escape_interface_90.tsv`.
