# General Gap Bridge Dependency Graph 90

## support-reduction update

The support-bound branch now includes `support_growth_partition`.

Important edges:

- `support_reduction_step_skeleton` supports `support_bound_justification` as a partition, not a completed reduction theorem.
- `family_chain_support_absorption` still depends on `family_chain_lift`.
- `family_chain_lift_bridge` is the next candidate expected to resolve the sharpest current blocker.
- `higher_support_escape_interface` remains open and blocks broader/full general statements until a higher-support bound is proved.

Runtime graph: `branch_4/90/runtime/general_gap_bridge_dependency_graph_90.tsv`.
