# Support Reduction Step Skeleton 90

## lemma

`support_growth_partition`.

## exact statement

Let `W` be a support `>8` normal minimal witness in the selected support-bound language. Then current evidence partitions `W` into one of the following branches:

1. a declared support-reduction operation applies and is required to produce a smaller normal witness;
2. the support-growth component is family-chain-shaped and requires `family_chain_support_lift`;
3. the witness is irreducible under the declared operations and is recorded as `higher_support_escape`.

## proof outline

1. Put `W` in support normal form.
2. Measure `W` by `lexicographic_support_tuple`.
3. Test declared reduction preconditions: redundant coordinate, equivalent coordinate contraction, active-support projection, canonical motif compression, frontier/tail capture after reduction.
4. If a valid operation is supplied, the support tuple decreases, and repeated reductions terminate.
5. If support reaches `<=8`, apply `limited_support8_shell16_boundary_bridge`.
6. If the family-chain component is the obstruction, the current 7/7 fresh package supplies bounded evidence, but a `family_chain_support_lift` lemma is still required.
7. If no reduction or family lift applies, classify the witness as `higher_support_escape`.

## status

`partition_ready_escape_open`.

The proof infrastructure for termination and limited-theorem application is current-scope proved, but the concrete operation-preservation theorem and family-chain lift are not proved. This is not a full support8 sufficiency proof.

Runtime skeleton: `branch_4/90/runtime/support_reduction_step_skeleton_90.tsv`.
