# General Gap Bridge Next Action Matrix 90

## recommendation

Top recommendation: `family_chain_lift_bridge`.

Second recommendation: `prove_support_reduction_operation_sublemma`.

Third recommendation: `higher_support_necessity_recheck`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `family_chain_lift_bridge` | 78 | 90 | 68 | 66 | 86 | 88 | 1 | `family_chain_lift_bridge` |
| `prove_support_reduction_operation_sublemma` | 70 | 88 | 76 | 76 | 80 | 84 | 2 | `prove_support_reduction_operation_sublemma` |
| `higher_support_necessity_recheck` | 68 | 84 | 58 | 64 | 88 | 80 | 3 | `higher_support_necessity_recheck` |
| `limited_to_broader_generalization_plan` | 62 | 80 | 55 | 60 | 82 | 72 | 4 | `limited_to_broader_generalization_plan` |
| `formalize_support_bound_completion` | 58 | 78 | 62 | 68 | 76 | 70 | 5 | `formalize_support_bound_completion` |
| `boj_problem_bridge_formalization` | 42 | 60 | 50 | 50 | 58 | 52 | 6 | `boj_problem_bridge_formalization` |

## rationale

`prove_support_reduction_step` did not prove full support8 sufficiency. It produced the stronger current contract: `support_growth_partition`. The support `>8` branch is now split into reducible operations, family-chain support-growth lift, and irreducible `higher_support_escape`.

The most concrete next blocker is `family_chain_support_lift`, because the family-chain lower layers are already `7/7` fresh but still need a lift from support-growth witnesses into the bounded family-chain language.
