# Support Bound Sublemma Proofs 90

## result

Attempted six support-bound sublemmas.

- `proved_under_current_scope`: `3`
- `proof_sketch_only`: `2`
- blocked sublemmas in this proof table: `1`

The support-reduction attempt moved the broad support `>8` branch to a named partition. The remaining blocked support-bound sublemma is the family-chain support lift, while operation-specific support reduction preservation remains proof-sketch only.

Runtime proof table: `branch_4/90/runtime/support_bound_sublemma_proofs_90.tsv`.
