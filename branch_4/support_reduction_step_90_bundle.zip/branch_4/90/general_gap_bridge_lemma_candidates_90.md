# General Gap Bridge Lemma Candidates 90

## support-reduction update

The support-bound candidate is now `proof_ready_skeleton_support_partition_ready_family_chain_lift_open`. This round did not prove unrestricted support8 sufficiency.

The new candidate facts are:

- `support_growth_partition_candidate`: support `>8` witnesses are partitioned into reducible, family-chain-lift-needed, or irreducible higher-support escape branches.
- `family_chain_lift_candidate`: now the top next lemma candidate.
- `support_reduction_operation_preservation_candidate`: second next candidate after the lift decision.

Runtime candidates: `branch_4/90/runtime/general_gap_bridge_lemma_candidates_90.tsv`.
