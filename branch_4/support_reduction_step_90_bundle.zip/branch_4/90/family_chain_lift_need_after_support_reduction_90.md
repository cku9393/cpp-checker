# Family-Chain Lift Need After Support Reduction 90

## decision

`family_chain_lift_bridge` is now the top next target.

The support-reduction attempt shows that the bounded family-chain package is a verified input, but the missing step is a lift from support-growth witnesses into the bounded family-chain obstruction language. Without that lift, family-chain evidence cannot be used as a general support-reduction operation.

Runtime table: `branch_4/90/runtime/family_chain_lift_need_after_support_reduction_90.tsv`.
