# Support Bound Lemma Skeleton 90

## lemma

`support_minimal_counterexample_reduces_to_support8_or_escape`.

## update after support-reduction attempt

The support-reduction round refines the support `>8` branch into `support_growth_partition`.

A support-minimal normal broader counterexample either:

1. has support `<=8`, where the already proved `limited_support8_shell16_boundary_bridge` applies;
2. has support `>8` and a declared reduction operation applies, in which case operation-specific preservation and measure decrease are still required;
3. has a family-chain support-growth component, in which case `family_chain_support_lift` is the next blocker; or
4. is irreducible under the declared operations and is recorded as `higher_support_escape`.

## final status

`proof_ready_skeleton_support_partition_ready_family_chain_lift_open`.

This is not a full support8 sufficiency theorem. The strongest current result is a proof-ready partition with termination and support8 re-entry infrastructure proved under current scope. The next blocker is `family_chain_lift_bridge`.

Runtime skeleton: `branch_4/90/runtime/support_bound_lemma_skeleton_90.tsv`.
