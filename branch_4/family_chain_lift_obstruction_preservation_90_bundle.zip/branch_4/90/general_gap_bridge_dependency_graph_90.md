# General Gap Bridge Dependency Graph 90

## updated dependency focus

The graph now routes the family-chain branch through payload semantics:

`source_form_recognizer` -> `refined_lift_map` -> `payload_semantics` -> `counterexample_status_semantics` -> `obstruction_preservation_skeleton`.

The remaining dependency is payload equality/refinement and counterexample-status preservation.

Runtime graph: `branch_4/90/runtime/general_gap_bridge_dependency_graph_90.tsv`.
