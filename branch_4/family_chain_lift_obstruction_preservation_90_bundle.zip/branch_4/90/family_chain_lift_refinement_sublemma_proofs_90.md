# Family-Chain Lift Refinement Sublemma Proofs 90

## updated after obstruction-preservation attempt

The refinement sublemma inventory now records payload well-definedness and conditional absorption as current-scope proved. Payload equality/refinement and counterexample-status preservation remain open.

Runtime proof table: `branch_4/90/runtime/family_chain_lift_refinement_sublemma_proofs_90.tsv`.
