# Higher-Support Escape Interface 90

## status after lift-map refinement

`higher_support_escape_interface_refined_lift_partial_open`.

The interface now separates:

- support `>8` no-reduction cases;
- recognized family-chain source-form cases whose obstruction preservation is still open;
- recognizer failure cases;
- family-chain language-extension cases;
- frontier/shell/tail uncovered cases.

The refined lift map reduces ambiguity, but higher-support escape remains open for broader/general theorem scope. No support9+ scan is performed or implied.

Runtime interface: `branch_4/90/runtime/higher_support_escape_interface_90.tsv`.
