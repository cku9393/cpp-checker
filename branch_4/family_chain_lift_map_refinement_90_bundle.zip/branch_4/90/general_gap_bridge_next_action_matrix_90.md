# General Gap Bridge Next Action Matrix 90

## recommendation after lift-map refinement

Top recommendation: `family_chain_lift_obstruction_preservation_proof`.

Second recommendation: `prove_support_reduction_operation_sublemma`.

Third recommendation: `higher_support_necessity_recheck`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `family_chain_lift_obstruction_preservation_proof` | 84 | 92 | 70 | 72 | 90 | 91 | 1 | `family_chain_lift_obstruction_preservation_proof` |
| `prove_support_reduction_operation_sublemma` | 74 | 88 | 76 | 76 | 82 | 85 | 2 | `prove_support_reduction_operation_sublemma` |
| `higher_support_necessity_recheck` | 72 | 84 | 58 | 64 | 88 | 80 | 3 | `higher_support_necessity_recheck` |
| `limited_to_broader_generalization_plan` | 66 | 80 | 55 | 60 | 82 | 72 | 4 | `limited_to_broader_generalization_plan` |
| `support_bound_completion` | 60 | 78 | 62 | 68 | 78 | 70 | 5 | `support_bound_completion` |
| `boj_problem_bridge_formalization` | 42 | 60 | 50 | 50 | 58 | 52 | 6 | `boj_problem_bridge_formalization` |

## rationale

`family_chain_lift_map_refinement` produced a component-level recognizer, a five-class source-form classification, and a refined lift map defined for recognized source forms. The remaining blocker is no longer map definition; it is obstruction/counterexample preservation for the lifted payload.

This remains a bridge/planning state, not a full general theorem.
