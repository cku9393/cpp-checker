# Support Reduction Step Obligation Inventory 90

## updated after lift-map refinement

The family-chain branch now uses the refined recognizer and refined lift map. It remains open only at payload-level obstruction/counterexample preservation.

Runtime inventory: `branch_4/90/runtime/support_reduction_step_obligation_inventory_90.tsv`.
