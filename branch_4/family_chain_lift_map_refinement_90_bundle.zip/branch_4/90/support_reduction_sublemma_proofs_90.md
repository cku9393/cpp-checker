# Support Reduction Sublemma Proofs 90

## updated after lift-map refinement

The family-chain branch is no longer blocked by lift-map definition. It is blocked by obstruction/counterexample payload preservation.

Runtime table: `branch_4/90/runtime/support_reduction_sublemma_proofs_90.tsv`.
