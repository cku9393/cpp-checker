# Support-Bound Lemma Skeleton 90

## lemma

`support_minimal_counterexample_reduces_to_support8_or_escape`.

## status after lift-map refinement

`proof_ready_skeleton_refined_lift_map_partial_higher_support_escape_open`.

The support-bound skeleton now has a refined family-chain branch:

- support `<=8` is handled by the proved limited bridge theorem;
- support `>8` reducible cases still need operation-specific preservation;
- recognized family-chain source-form cases have a defined refined lift into fresh bounded family-chain layers;
- obstruction/counterexample preservation for lifted payloads remains open;
- recognition or preservation failure is a named higher-support or non-family-chain escape.

This is not a full support8 sufficiency theorem and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/support_bound_lemma_skeleton_90.tsv`.
