# General Gap Bridge Dependency Graph 90

## updated dependency focus

The graph now routes `family_chain_lift` through the refined recognizer and refined lift map.

New dependency chain:

`family_chain_source_form_recognizer` -> `family_chain_refined_lift_map` -> `family_chain_lift_preservation_obligations` -> `family_chain_lift_obstruction_preservation_proof`.

The 7/7 family-chain lower-layer package remains a verified target-freshness input, not a proof of arbitrary lift preservation.

Runtime graph: `branch_4/90/runtime/general_gap_bridge_dependency_graph_90.tsv`.
