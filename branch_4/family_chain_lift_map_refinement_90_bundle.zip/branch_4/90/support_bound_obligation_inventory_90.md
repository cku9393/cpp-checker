# Support-Bound Obligation Inventory 90

## updated after lift-map refinement

The support-bound inventory now treats the family-chain branch as refined but not closed.

Current sharp blockers:

- `obstruction_payload_preservation` for recognized lifted family-chain objects;
- operation-specific support-reduction preservation;
- higher-support bound for escape closure.

Runtime inventory: `branch_4/90/runtime/support_bound_obligation_inventory_90.tsv`.
