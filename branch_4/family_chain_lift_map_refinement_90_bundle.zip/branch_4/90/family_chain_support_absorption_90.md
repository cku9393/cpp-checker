# Family-Chain Support Absorption 90

## status after lift-map refinement

`partial_absorption_refined_lift_preservation_open`.

The current bounded family-chain package absorbs a support-growth family-chain case only after:

1. the source-form recognizer accepts;
2. the refined lift map produces a target object in pair52/triple53/quad55/quint57/sext57/sept57/high57;
3. obstruction/counterexample payload preservation is proved.

Steps 1 and 2 are now proof-ready/current-scope established as contracts. Step 3 remains open.

Runtime table: `branch_4/90/runtime/family_chain_support_absorption_90.tsv`.
