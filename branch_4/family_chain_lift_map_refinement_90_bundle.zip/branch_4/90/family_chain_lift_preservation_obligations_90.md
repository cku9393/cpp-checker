# Family-Chain Lift Preservation Obligations 90

## purpose

This inventory separates recognizer, totality, target freshness, canonicalization, and obstruction-preservation obligations for the refined lift map.

Runtime inventory: `branch_4/90/runtime/family_chain_lift_preservation_obligations_90.tsv`.
