# Family-Chain Lift Skeleton 90

## lemma

`family_chain_lift_or_higher_support_escape`, refined by `lift_map_refinement_or_higher_support_escape`.

## exact statement

For a support `>8` normal witness in the family-chain branch of `support_growth_partition`, the refined recognizer either accepts a bounded family-chain source form or routes the witness to a named escape. For recognized source forms, the refined lift map is defined and targets the current fresh bounded family-chain package. The remaining proof obligation is payload-level obstruction/counterexample preservation.

## current proof status

`partial_lift_refined_recognized_source_map_preservation_open`.

What is proved under current scope:

- target-package freshness and `7/7` lower-layer provenance;
- conditional bounded-theorem applicability after successful recognized lift;
- refined lift-map totality for recognized source forms;
- named escape routing for recognizer or preservation failure.

What is not proved:

- arbitrary support-growth source-form completeness;
- canonicalization commutation as a mathematical equivalence theorem;
- obstruction/counterexample preservation for lifted payloads;
- full support8 sufficiency or the full general theorem.

Runtime skeletons:

- `branch_4/90/runtime/family_chain_lift_skeleton_90.tsv`
- `branch_4/90/runtime/family_chain_lift_map_refinement_skeleton_90.tsv`
