# Limited-To-Broader Generalization Map 90

## status after lift-map refinement

The proved limited theorem remains intact. Broader lifting is still blocked by support-bound completion.

The family-chain branch now has a refined source-form recognizer and a defined lift map for recognized source forms, but obstruction/counterexample preservation is still open.

Runtime map: `branch_4/90/runtime/limited_to_broader_generalization_map_90.tsv`.
