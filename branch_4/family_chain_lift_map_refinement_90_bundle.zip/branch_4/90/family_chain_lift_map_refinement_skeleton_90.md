# Family-Chain Lift Map Refinement Skeleton 90

## lemma

`lift_map_refinement_or_higher_support_escape`.

## exact statement

For a support `>8` witness in the family-chain branch of `support_growth_partition`, the source-form recognizer either:

1. accepts the witness as a recognized family-chain source form, in which case the refined lift map is defined into the fresh bounded family-chain target package; or
2. rejects or reaches a preservation gap, in which case the witness is routed to a named higher-support or non-family-chain escape.

The refined map is proof-ready for recognized-source totality and target applicability. Obstruction/counterexample preservation remains open.

## case split

- recognized source form, lift succeeds: target freshness and bounded-theorem applicability are proved under current scope.
- recognizable after canonical compression: proof-sketch pending canonicalization commutation.
- recognizer fails: named higher-support or language-extension escape.
- non-family-chain case: handled by support-reduction operation branch, not by this lift.

## final status

`partial_refinement_proved_escape_open`.

This is not full family-chain lift correctness and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/family_chain_lift_map_refinement_skeleton_90.tsv`.
