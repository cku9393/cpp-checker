# Support Reduction Step Skeleton 90

## selected statement

`support_growth_partition`.

## status after lift-map refinement

`partition_ready_refined_family_chain_source_form_escape_open`.

The support `>8` branch is partitioned into:

- reducible support operation cases;
- recognized family-chain source-form cases with a defined refined lift map;
- recognizable-after-canonical-compression cases;
- recognizer failure / preservation failure named escapes;
- irreducible higher-support escape.

The family-chain target package is fresh and the refined lift is defined on recognized source forms. The support-reduction theorem is still not complete because obstruction/counterexample preservation and operation-specific reduction preservation remain open.

Runtime skeleton: `branch_4/90/runtime/support_reduction_step_skeleton_90.tsv`.
