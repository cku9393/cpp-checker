# General Gap Bridge Lemma Candidates 90

## next candidate

First candidate after this round: `family_chain_lift_obstruction_preservation_candidate`.

The previous `family_chain_lift_map_refinement_candidate` is partially addressed: the recognizer, classification, and refined lift map are now first-class artifacts. The remaining proof target is payload-level obstruction/counterexample preservation for recognized lifted objects.

Runtime candidates: `branch_4/90/runtime/general_gap_bridge_lemma_candidates_90.tsv`.
