# Support-Bound Sublemma Proofs 90

## updated after lift-map refinement

The support8 and limited-bridge sublemmas remain current-scope proved. The family-chain support-growth sublemma is now blocked specifically by `obstruction_payload_preservation`, not by missing map definition.

Runtime table: `branch_4/90/runtime/support_bound_sublemma_proofs_90.tsv`.
