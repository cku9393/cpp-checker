# Family Chain Lower Layers Priority Map 90

## purpose

This map compares the family-chain lower imported layers against the lower-frontier shell11/shell12 inventory-only rows.

The conclusion is that family-chain lower layers are the next higher-value provenance target.

## current family-chain state

The top theorem object layer is already fresh current-runtime generated:

- `bounded family-chain theorem`
- `family-chain self verification`
- constructor: `build_current_family_chain_output_57_theorem_objects_`
- fallback hit: `0`

The remaining caveat is below that theorem object layer.

## priority order

1. `pair_expansion_aggregate_52`
2. `triple_family_expansion_theorem_data_53`
3. `quadruple_family_expansion_theorem_data_55`
4. `quintuple_family_expansion_theorem_data_57`
5. `sextuple_family_expansion_theorem_data_57`
6. `septuple_family_expansion_theorem_data_57`
7. `high_family_expansion_theorem_data_57`

## rationale

- The pair-expansion aggregate is named directly by the current support theorem constructor caveat.
- Triple and quadruple layers already have slow rebuild functions and are foundational for deeper layers.
- Quintuple has a slow rebuild path and directly feeds unified family-chain counts.
- Sextuple/septuple/high-family are larger and should follow only after the lower layers are stabilized.

## decision

Do not spend this round freshizing shell11/shell12 inventory-only rows. Keep them exposed as nonblocking perimeter rows and move the next freshization round to family-chain lower imported layers.
