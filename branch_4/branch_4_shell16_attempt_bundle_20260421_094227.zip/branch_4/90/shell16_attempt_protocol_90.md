# Shell16 Attempt Protocol 90

## preconditions

- release compile and LOCAL_TEST compile remain verified.
- pass1/pass2/pass3 remain `support8_authoritative_completion_locked`.
- required docs remain `39/39` and required artifacts remain `8/8`.
- top-level provenance remains fresh `16`, imported `0`, mixed `0`, archival `3`.
- family-chain lower layers remain total `7`, fresh `7`, imported `0`.
- shell16 artifact, document, audit, feasibility, and guardrail contracts are present.

## required code paths used by the attempt

- pass1 builder: `scan_shell16_frontier_non_promoting_attempt_`.
- candidate enumerator: shell16-specific enumerator, not a shell15 artifact copy.
- pass2/pass3 cache loader: `load_current_shell16_runtime_artifact_`.
- audit writer: shell16-specific writer that records constructor, cache path, fallback visibility, fingerprints, and survivor audits.

## allowed outcomes

| outcome | classification |
| --- | --- |
| shell16 survivors zero after validated shell16 scan | may close `shell16_escape` only after rowset, fingerprint, fallback, stale-artifact, and pass rerun gates |
| shell16 survivors nonzero | opens named shell16 survivor blocker; no theorem promotion |
| scan timeout or too expensive | opens cost/pruning blocker; no theorem promotion |
| canonicalization mismatch | opens canonicalization blocker; no theorem promotion |
| fallback hit | opens provenance blocker; no theorem promotion |
| stale artifact | opens stale-artifact blocker; no theorem promotion |

## pass behavior

Pass1 must run the shell16 builder if a future attempt is selected. Pass2/pass3 must use a stable validated shell16 cache-load path. If either path falls back to imported or shell15 data, shell16 remains unproved.

## current attempt result

- classification: `shell16_survivor_probe_completed_zero_survivors_no_promotion`
- candidate universe: `4`
- raw/canonical/outside-bounded: `8/4/4`
- local exact/plus-one/theorem-preserving survivors: `2/0/0`
- fingerprint: `956:969644237003470976`
- fallback reachable/hit: `0/0`
- stale artifact status: `fresh`

## tail bridge update rule

This attempt updates the tail bridge shell16 escape to `shell16_boundary_checked_zero_theorem_survivors_no_promotion`. It does not close the bridge as a theorem; that requires `shell16_result_promotion_review` or a separate absorption-step proof.

## rollback and non-regression

Any shell16 attempt failure must leave support8 lock, top-level provenance, family-chain closure, and lower-frontier inventory-only decisions unchanged. The failing gate must be recorded before any theorem promotion is considered.
