# General Gap Bridge Next Action Matrix 90

## recommendation

Top recommendation: `prove_minimal_counterexample_reduction`.

Second recommendation: `tail_monotonicity_bridge`.

Third recommendation: `shell16_preflight_refactor`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `prove_minimal_counterexample_reduction` | 70 | 95 | 55 | 65 | 75 | 92 | 1 | `prove_minimal_counterexample_reduction` |
| `tail_monotonicity_bridge` | 65 | 85 | 50 | 55 | 70 | 80 | 2 | `tail_monotonicity_bridge` |
| `shell16_preflight_refactor` | 62 | 75 | 70 | 60 | 65 | 78 | 3 | `shell16_preflight_refactor` |
| `frontier_ladder_completeness_bridge` | 66 | 78 | 55 | 50 | 68 | 72 | 4 | `frontier_ladder_completeness_bridge` |
| `family_chain_lift_bridge` | 72 | 74 | 45 | 45 | 75 | 70 | 5 | `family_chain_lift_bridge` |
| `formalize_support_bound_lemma` | 40 | 90 | 80 | 80 | 40 | 68 | 6 | `formalize_support_bound_lemma` |
| `limited_bridge_theorem_proof_attempt` | 50 | 88 | 60 | 70 | 55 | 66 | 7 | `limited_bridge_theorem_proof_attempt` |
| `boj_problem_bridge_formalization` | 58 | 65 | 50 | 50 | 60 | 62 | 8 | `boj_problem_bridge_formalization` |

## rationale

`prove_minimal_counterexample_reduction` is first because it decides whether the current finite package is the right proof substrate and whether shell16 or higher-support obligations are actually necessary. `tail_monotonicity_bridge` is second because the tail theorem is the current route beyond finite shell evidence. `shell16_preflight_refactor` is third because shell16 should only be opened after the reduction/tail bridge says it is needed or useful.
