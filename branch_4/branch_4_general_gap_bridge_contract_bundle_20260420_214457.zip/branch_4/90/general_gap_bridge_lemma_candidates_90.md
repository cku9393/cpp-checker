# General Gap Bridge Lemma Candidates 90

## purpose

These are lemma candidates, not proved theorem statements. They identify what can be derived from the current verified package and what still needs proof.

## status split

- `current_verified_derivable`: finite support8 closure lemma, archive independence lemma.
- `candidate_needs_proof`: minimal counterexample reduction, tail monotonicity, family-chain lift, frontier ladder completeness.
- `candidate_needs_shell16`: shell15/tail absorption through shell16 boundary.
- `candidate_needs_higher_support_bound`: support8 sufficiency/support bound.
- `candidate_needs_solver_constructivity`: BOJ constructive bridge.

## next lemma target

The first lemma to attempt is `minimal_counterexample_reduction_candidate`, because it determines which finite obligations are sufficient and whether shell16 or higher-support work is actually necessary.
