# General Gap Bridge Lemma Candidates 90

## purpose

These are lemma candidates, not proved theorem statements. They identify what can be derived from the current verified package and what still needs proof.

## status split

- `current_verified_derivable`: finite support8 closure lemma, archive independence lemma.
- `proof_ready_skeleton`: minimal counterexample reduction under the selected limited support8 statement; tail monotonicity bridge under checked-tail absorption plus shell16 escape.
- `candidate_needs_proof`: tail monotonicity, family-chain lift, frontier ladder completeness.
- `candidate_needs_shell16`: shell15/tail absorption through shell16 boundary.
- `candidate_needs_higher_support_bound`: support8 sufficiency/support bound.
- `candidate_needs_solver_constructivity`: BOJ constructive bridge.

## next lemma target

The first action to attempt next is `shell16_preflight_refactor`. The `tail_monotonicity_candidate` now proves checked-tail capture under current scope and routes unchecked extension to shell16; it is not full tail monotonicity.
