# Minimal Counterexample Escape Interface 90

## purpose

This interface fixes where a minimal witness goes if it cannot be captured by the current finite package.

## escape classes

- `none_current_scope`: captured by the current finite package; contradiction uses support8 closure.
- `tail_monotonicity_escape`: checked tail witness is now closed by the tail bridge; extension-tail absorption remains open.
- `shell16_escape`: witness crosses the shell15/current-tail boundary or the first unchecked tail-extension boundary and requires shell16 preflight.
- `higher_support_escape`: witness cannot be reduced to support<=8 and requires a support-bound lemma.
- `boj_constructivity_escape`: theorem-to-solver constructivity is required, but not for the mathematical bridge.
- `archive_independence_escape`: archival-only note confusion; already handled by provenance separation.

## next blocker

The next blocker for the reduction skeleton is `shell16_escape`.
