# General Gap Bridge Next Action Matrix 90

## recommendation

Top recommendation: `shell16_preflight_refactor`.

Second recommendation: `prove_or_refine_tail_absorption_step`.

Third recommendation: `limited_bridge_theorem_proof_attempt`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `shell16_preflight_refactor` | 76 | 82 | 70 | 60 | 86 | 88 | 1 | `shell16_preflight_refactor` |
| `prove_or_refine_tail_absorption_step` | 58 | 90 | 65 | 75 | 74 | 82 | 2 | `prove_or_refine_tail_absorption_step` |
| `limited_bridge_theorem_proof_attempt` | 66 | 90 | 65 | 70 | 72 | 78 | 3 | `limited_bridge_theorem_proof_attempt` |
| `tail_monotonicity_bridge` | 55 | 88 | 50 | 55 | 88 | 70 | 4 | `bounded_tail_bridge_proof_ready` |
| `frontier_ladder_completeness_bridge` | 66 | 78 | 55 | 50 | 68 | 72 | 5 | `frontier_ladder_completeness_bridge` |
| `family_chain_lift_bridge` | 72 | 74 | 45 | 45 | 75 | 70 | 6 | `family_chain_lift_bridge` |
| `formalize_support_bound_lemma` | 40 | 90 | 80 | 80 | 40 | 68 | 7 | `formalize_support_bound_lemma` |
| `boj_problem_bridge_formalization` | 58 | 65 | 50 | 50 | 60 | 62 | 8 | `boj_problem_bridge_formalization` |

## rationale

`tail_monotonicity_bridge` now proves checked-tail capture under the current support8 range and routes the first unchecked extension to shell16 unless a separate absorption step is supplied. Therefore `shell16_preflight_refactor` is first. `prove_or_refine_tail_absorption_step` is second as the proof-side alternative to running shell16. `limited_bridge_theorem_proof_attempt` is third and should wait until the shell16/absorption fork is resolved or explicitly assumed.
