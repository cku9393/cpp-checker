# Tail Monotonicity Limited Bridge Skeleton 90

## theorem name

`support8_checked_tail_absorption_or_shell16_escape_bridge`

## exact statement

Assume a minimal counterexample witness reaches the `tail_monotonicity_escape` interface. If the witness is represented inside the current checked support8 shell15 tail range `9..15`, then the current outside-bounded tail pattern theorem and tail obstruction chain capture it, so it cannot remain a theorem-preserving survivor. If the witness requires extending beyond that checked range, this round does not claim absorption; the witness is routed to `shell16_escape` or to the separate `prove_or_refine_tail_absorption_step` obligation.

## assumptions

- support8 outside-bounded tail pattern theorem is current verified.
- support8 tail obstruction chain theorem is current verified.
- support8 authoritative completion lock remains current verified.
- minimal counterexample reduction escape interface is accepted as the routing contract.
- shell16 scan is not executed in this round.

## conclusion

Checked tail absorption is proved under current scope. Bounded extension absorption is proof-ready as a skeleton but still open at the shell16/absorption-step boundary.

## verified inputs used

- `support8_tail_stabilization_certificate_90.tsv`
- `support8_tail_obstruction_chain_notes_90.md`
- `support8_tail_candidate_fingerprints_90.tsv`
- `minimal_counterexample_escape_interface_90.tsv`
- `current_support8_closure_certificate_90.tsv`

## proof steps

1. Normalize the tail witness into checked or extension tail normal form.
2. If checked, use the tail pattern certificate: support7/support8 outside-bounded candidates are `2/2`, and theorem-preserving survivors are `0/0`.
3. If checked, use the tail obstruction chain: shell15, tail theorem, artifact, document, rerun, and freshness gates all validate.
4. If extension, compute positive `distance_beyond_checked_bound` in the tail measure.
5. If an absorption step is later supplied, require measure decrease and counterexample-status preservation.
6. If no absorption step is supplied, classify the first extension boundary as `shell16_escape`.

## final status

- status: `bounded_tail_bridge_proof_ready`
- checked tail absorption: `proved_under_current_scope`
- extension tail absorption: `blocked_by_absorption_step`
- shell16 escape: `promoted_to_next_blocker`
- full tail monotonicity: not proved
- full general theorem: not proved
