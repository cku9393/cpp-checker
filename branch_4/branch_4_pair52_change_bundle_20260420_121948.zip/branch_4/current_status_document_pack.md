# Branch 4 Current Status Document Pack

## purpose

This file collects the minimum document set needed to show the current branch 4 state accurately.

The current branch 4 truth is not "BOJ solver completed".  The current verified claim is:

- current support8 proof-system classification: `support8_authoritative_completion_locked`
- release compile: verified
- LOCAL_TEST compile: verified
- LOCAL_TEST pass1/pass2/pass3: `support8_authoritative_completion_locked`
- required docs: `39 / 39`
- required artifacts: `8 / 8`
- top-level provenance: fresh `16`, validated-imported `0`, mixed `0`, archival-only `3`

The remaining caveat is not a top-level support8 lock failure. It is the broader provenance perimeter: lower-frontier inventory-only shell11/shell12 rows and deeper family-chain imported layers. The first family-chain lower target, `pair_expansion_aggregate_52`, is now fresh current-runtime generated.

## read order

1. `project_status_summary.md`
2. `current_workspace_reality_check.md`
3. `current_status_authoritative_longform.md`
4. `90/proof_system_reproduction_report_90.md`
5. `90/proof_system_contract_memo_90.md`
6. `90/runtime/provenance_audit_fingerprint_90.tsv`
7. `90/runtime/theorem_data_provenance_inventory_90.tsv`
8. `90/runtime/lower_frontier_ladder_inventory_90.tsv`
9. `90/runtime/support8_antecedent15_shell_theorem_generation_audit_90.tsv`

## root status documents

| path | role |
| --- | --- |
| `project_status_summary.md` | shortest human-readable current status summary |
| `current_workspace_reality_check.md` | current filesystem / compile / rerun / provenance counts |
| `current_status_authoritative_longform.md` | main longform current-state explanation |
| `authoritative_completion_to_100_plan_longform.md` | what remains before project-wide 100-point completion |
| `theorem_data_promotion_to_100_plan_longform.md` | theorem-data promotion roadmap and remaining provenance perimeter |
| `mathematical_progress_to_100_plan_longform.md` | mathematical progress and remaining mathematical boundary |
| `progress_history_1_to_85_longform.md` | historical record, including later 85-90 reconstruction notes |

## current 90 proof-system reports

| path | role |
| --- | --- |
| `90/proof_system_reproduction_report_90.md` | compile/pass/reproduction summary for the current runtime |
| `90/proof_system_contract_memo_90.md` | code contract: required docs/artifacts, audit gates, metadata split |
| `90/theorem_data_provenance_inventory_90.md` | markdown view of top-level theorem-data provenance |
| `90/basis_family_fresh_generation_report_90.md` | basis/family substrate freshization summary |
| `90/family_chain_fresh_constructor_report_90.md` | family-chain theorem object current constructor report |
| `90/shell15_frontier_fresh_derivation_report_90.md` | shell15 frontier pair fresh derivation report |
| `90/lower_frontier_ladder_freshization_report_90.md` | lower frontier ladder direct dependency freshization report |
| `90/support8_antecedent15_shell_theorem_freshization_report_90.md` | shell theorem freshization result |
| `90/perimeter_priority_decision_memo_90.md` | decision memo for inventory-only shell11/shell12 rows vs family-chain lower layers |
| `90/lower_frontier_inventory_only_scope_memo_90.md` | scope memo for the four nonblocking inventory-only rows |
| `90/lower_frontier_inventory_only_freshization_report_90.md` | result report for the inventory-only decision round |
| `90/family_chain_lower_layers_priority_map_90.md` | priority map for the next family-chain lower-layer target |
| `90/pair_expansion_aggregate_52_scope_memo_90.md` | scope/dependency map for output 52 |
| `90/pair_expansion_aggregate_52_feasibility_90.md` | semantics/equality/feasibility contract for output 52 |
| `90/pair_expansion_aggregate_52_freshization_report_90.md` | current constructor/cache result for output 52 |

## runtime machine-readable evidence

| path | role |
| --- | --- |
| `90/runtime/provenance_audit_fingerprint_90.tsv` | top-level provenance counts and current bundle metadata |
| `90/runtime/theorem_data_provenance_inventory_90.tsv` | item-by-item validation/provenance inventory |
| `90/runtime/provenance_audit_report_90.md` | short generated provenance report |
| `90/runtime/provenance_summary_90.md` | generated provenance summary |
| `90/runtime/artifact_completion_audit_90.tsv` | required artifact audit |
| `90/runtime/document_completion_audit_90.tsv` | required document audit |
| `90/runtime/rerun_completion_audit_90.tsv` | release/LOCAL_TEST rerun audit |
| `90/runtime/support8_local_test_success_stamp_90.tsv` | LOCAL_TEST success stamp |
| `90/runtime/support8_release_compile_stamp_90.tsv` | release compile stamp |

## freshized theorem-data evidence

| path | role |
| --- | --- |
| `90/runtime/exact_minimal_basis_generation_audit_90.tsv` | exact minimal basis payload fresh generation audit |
| `90/runtime/exact_minimal_basis_payload_90.tsv` | current exact minimal basis payload |
| `90/runtime/exact_minimal_basis_fingerprint_90.tsv` | exact basis payload fingerprint |
| `90/runtime/family_chain_constructor_audit_90.tsv` | family-chain current constructor audit |
| `90/runtime/family_chain_generation_audit_90.tsv` | family-chain generation provenance audit |
| `90/runtime/antecedent_plus_twelve_frontier_generation_audit_90.tsv` | antecedent plus twelve frontier current audit |
| `90/runtime/support8_antecedent15_frontier_generation_audit_90.tsv` | support8 antecedent15 frontier current audit |
| `90/runtime/shell15_frontier_generation_fingerprint_90.tsv` | shell15 frontier pair fingerprint |
| `90/runtime/lower_frontier_ladder_generation_audit_90.tsv` | lower-frontier direct dependency subset generation audit |
| `90/runtime/lower_frontier_ladder_constructor_fingerprint_90.tsv` | lower-frontier constructor fingerprint |
| `90/runtime/lower_frontier_ladder_rowset_equality_90.tsv` | lower-frontier row-set equality audit |
| `90/runtime/support8_antecedent15_shell_theorem_generation_audit_90.tsv` | shell theorem freshization audit |
| `90/runtime/lower_frontier_inventory_only_dependency_audit_90.tsv` | dependency audit for shell11/shell12 inventory-only rows |
| `90/runtime/lower_frontier_inventory_only_decision_90.tsv` | final decision TSV for shell11/shell12 inventory-only rows |
| `90/runtime/lower_frontier_inventory_only_generation_audit_90.tsv` | generation-attempt audit for the nonblocking decision |
| `90/runtime/family_chain_lower_layers_inventory_90.tsv` | family-chain lower imported layer priority inventory |
| `90/runtime/pair_expansion_aggregate_52_payload_90.tsv` | current-generated 28-region pair-expansion payload |
| `90/runtime/pair_expansion_aggregate_52_generation_audit_90.tsv` | pair52 current constructor/cache audit |
| `90/runtime/pair_expansion_aggregate_52_fingerprint_90.tsv` | pair52 payload/runtime fingerprint |
| `90/runtime/pair_expansion_aggregate_52_rowset_equality_90.tsv` | pair52 imported comparison/equality audit |
| `90/runtime/pair_expansion_aggregate_52_constructor_fingerprint_90.tsv` | pair52 constructor/cache fingerprint |
| `90/runtime/family_chain_lower_layers_generation_audit_90.tsv` | family-chain lower-layer generation status |
| `90/runtime/family_chain_lower_layers_fingerprint_90.tsv` | family-chain lower-layer count/fingerprint summary |

## preserved archival notes

These files should be read as preserved 90-bundle archival notes, not as stronger claims than the current runtime evidence.

| path | role |
| --- | --- |
| `90/project_status_summary_90.md` | preserved bundle status summary |
| `90/support8_antecedent15_shell_theorem_notes_90.md` | preserved shell theorem note |
| `90/support8_outside_bounded_tail_pattern_notes_90.md` | preserved tail pattern note |
| `90/support8_tail_obstruction_chain_notes_90.md` | preserved tail chain note |
| `90/support8_authoritative_completion_lock_notes_90.md` | preserved completion lock note |
| `90/artifact_completion_notes_90.md` | preserved artifact completion note |
| `90/document_completion_audit_notes_90.md` | preserved document audit note |
| `90/support8_rerun_completion_notes_90.md` | preserved rerun completion note |

## current caveat boundary

The top-level theorem/audit inventory has no remaining `current_runtime_validated_imported_data` or `mixed` item.

However, the lower-frontier first-class inventory still exposes four inventory-only mixed rows outside the direct shell15 dependency subset:

- `antecedent_plus_eight_frontier`
- `support8_antecedent11_frontier`
- `antecedent_plus_nine_frontier`
- `support8_antecedent12_frontier`

These do not block the current support8 lock and are now explicitly retained as `keep_inventory_only_nonblocking`.

`pair_expansion_aggregate_52` is now fresh current-runtime generated:

- constructor/cache: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_` -> `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- counts: regions `28`, candidates `501/501/182`, survivors `0/0/0`
- fingerprint: `6003:2005080337376028436`

The next provenance cleanup target is `triple_family_expansion_theorem_data_53`.
