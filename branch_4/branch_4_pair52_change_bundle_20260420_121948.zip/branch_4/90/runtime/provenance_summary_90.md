# Provenance Summary 90

summary
- item count: `19`
- fresh current runtime generated: `16`
- current runtime validated imported data: `0`
- mixed: `0`
- archival only: `3`
- current support8 classification: `support8_authoritative_completion_locked`
- basis-only generation label: `fresh_current_runtime_generated`
- family-chain generation label: `fresh_current_runtime_generated`
- family-chain constructor: `build_current_family_chain_output_57_theorem_objects_`
- lower-frontier inventory-only decision: `keep_inventory_only_nonblocking=4`
- pair-expansion aggregate 52 label: `fresh_current_runtime_generated`
- family-chain lower-layer fresh/imported: `1 / 6`
- next broader perimeter target: `triple_family_expansion_theorem_data_53`
