# Proof System Reproduction Report 90

1. active workspace root
- `/Users/free_1/Library/Mobile Documents/iCloud~md~obsidian/Documents/cpp-checker`
2. active runtime data root
- `/Users/free_1/Library/Mobile Documents/iCloud~md~obsidian/Documents/cpp-checker/branch_4/90/runtime`
3. compile status
- release compile: verified
- LOCAL_TEST compile: verified
4. pass status
- pass1: `support8_authoritative_completion_locked`
- pass2: `support8_authoritative_completion_locked`
- pass3: `support8_authoritative_completion_locked`
5. current captured run status
- current reproducible classification: `support8_authoritative_completion_locked`
- archival classification: `support8_authoritative_completion_locked`
- lock achieved in captured run: `yes`
6. current counts before follow-up rerun
- required docs: `39` / `39` in the captured run
- required artifacts: `8` / `8`
7. provenance audit summary
- item count: `19`
- fresh current runtime generated: `16`
- current runtime validated imported data: `0`
- mixed: `0`
- archival only: `3`
- basis-only generation label: `fresh_current_runtime_generated` with promoted items `4`
- family-chain generation label: `fresh_current_runtime_generated` with promoted items `2`
- family-chain constructor: `build_current_family_chain_output_57_theorem_objects_` fallbackHit=`0`
8. perimeter decision summary
- inventory-only shell11/shell12 rows: `4`
- `freshize_now`: `0`
- `keep_inventory_only_nonblocking`: `4`
- `defer_after_family_chain`: `0`
9. pair-expansion aggregate 52
- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_`
- pass2/pass3 cache loader: `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- region count: `28`
- raw / canonical / deduplicated candidates: `501 / 501 / 182`
- survivor counts: `0 / 0 / 0`
- payload fingerprint: `6003:2005080337376028436`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- fallback reachable / hit: `1 / 0`
10. family-chain lower-layer priority map
- written: `yes`
- lower-layer fresh count: `1`
- lower-layer imported count: `6`
- next target: `triple_family_expansion_theorem_data_53`
11. first failing gate in captured run
- `none` with detail ``
12. next concrete action
- preserve the current support8 lock while moving the next provenance target to `triple_family_expansion_theorem_data_53`. Lower-frontier inventory-only shell11/shell12 rows remain visible nonblocking perimeter rows.
