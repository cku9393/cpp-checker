# Family Chain Lower Layers Priority Map 90

## purpose

This map compares the family-chain lower layers after the `pair_expansion_aggregate_52` freshization round.

The conclusion is that output `52` is now current constructor/cache-backed, and output `53` is the next higher-value provenance target.

## current family-chain state

The top theorem object layer is already fresh current-runtime generated:

- `bounded family-chain theorem`
- `family-chain self verification`
- constructor: `build_current_family_chain_output_57_theorem_objects_`
- fallback hit: `0`

The remaining caveat is now below the pair-expansion layer.

## completed lower layer

`pair_expansion_aggregate_52`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_`
- pass2/pass3 cache loader: `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- regions: `28`
- raw / canonical / deduplicated: `501 / 501 / 182`
- survivors: `0 / 0 / 0`
- payload fingerprint: `6003:2005080337376028436`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- fallback hit: `0`

## priority order

1. `triple_family_expansion_theorem_data_53`
2. `quadruple_family_expansion_theorem_data_55`
3. `quintuple_family_expansion_theorem_data_57`
4. `sextuple_family_expansion_theorem_data_57`
5. `septuple_family_expansion_theorem_data_57`
6. `high_family_expansion_theorem_data_57`

## rationale

- The pair-expansion aggregate is no longer the blocker; it is generated/loaded from current runtime artifacts.
- Triple and quadruple layers already have slow rebuild functions and are foundational for deeper layers.
- Quintuple has a slow rebuild path and directly feeds unified family-chain counts.
- Sextuple/septuple/high-family are larger and should follow only after the lower layers are stabilized.

## decision

Do not spend the next round freshizing shell11/shell12 inventory-only rows. Keep them exposed as nonblocking perimeter rows and move the next freshization round to `triple_family_expansion_theorem_data_53`.
