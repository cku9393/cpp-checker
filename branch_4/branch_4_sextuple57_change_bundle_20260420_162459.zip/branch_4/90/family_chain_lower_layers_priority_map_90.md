# Family Chain Lower Layers Priority Map 90

## purpose

This map compares the family-chain lower layers after the `sextuple_family_expansion_theorem_data_57` freshization round.

The conclusion is that outputs `52`, `53`, `55`, and the quintuple/sextuple `57` layers are now current constructor/cache-backed. The next exact target is the septuple `57` layer.

## current family-chain state

The top theorem object layer is already fresh current-runtime generated:

- `bounded family-chain theorem`
- `family-chain self verification`
- constructor: `build_current_family_chain_output_57_theorem_objects_`
- fallback hit: `0`

The remaining caveat is now below the sextuple-family layer.

## completed lower layer

`pair_expansion_aggregate_52`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_`
- pass2/pass3 cache loader: `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- regions: `28`
- raw / canonical / deduplicated: `501 / 501 / 182`
- survivors: `0 / 0 / 0`
- payload fingerprint: `6003:2005080337376028436`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- fallback hit: `0`

`triple_family_expansion_theorem_data_53`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_triple_family_expansion_theorem_data_53_from_pair52_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_triple_family_expansion_theorem_data_53_runtime_artifact_`
- regions: `35`
- raw / canonical / deduplicated: `2110 / 2110 / 282`
- survivors: `0 / 0 / 0`
- payload fingerprint: `11888:3562593626991170520`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream pair52 fallback hit: `0`
- fallback hit: `0`

`quadruple_family_expansion_theorem_data_55`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_quadruple_family_expansion_theorem_data_55_from_triple53_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_quadruple_family_expansion_theorem_data_55_runtime_artifact_`
- regions: `35`
- raw / canonical / deduplicated: `3962 / 3962 / 294`
- survivors: `0 / 0 / 0`
- payload fingerprint: `15637:3406948456738223960`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- fallback hit: `0`

`quintuple_family_expansion_theorem_data_57`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_quintuple_family_expansion_theorem_data_57_from_quad55_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_quintuple_family_expansion_theorem_data_57_runtime_artifact_`
- regions: `21`
- raw / canonical / deduplicated: `3634 / 3634 / 294`
- survivors: `0 / 0 / 0`
- payload fingerprint: `11519:14985224666762482157`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream quad55 fallback hit: `0`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- fallback hit: `0`

`sextuple_family_expansion_theorem_data_57`:

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_sextuple_family_expansion_theorem_data_57_from_quintuple57_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_sextuple_family_expansion_theorem_data_57_runtime_artifact_`
- regions: `7`
- raw / canonical / deduplicated: `1632 / 1632 / 294`
- survivors: `0 / 0 / 0`
- payload fingerprint: `4567:5441664472856347648`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream quintuple57 fallback hit: `0`
- upstream quad55 fallback hit: `0`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- fallback hit: `0`

## priority order

1. `septuple_family_expansion_theorem_data_57`
2. `high_family_expansion_theorem_data_57`

## rationale

- The pair-expansion aggregate is no longer the blocker; it is generated/loaded from current runtime artifacts.
- Triple-family theorem data 53 is no longer the blocker; it is generated/loaded from current runtime artifacts with upstream pair52 fallback hit `0`.
- Quadruple-family theorem data 55 is no longer the blocker; it is generated/loaded from current runtime artifacts with upstream triple53 and pair52 fallback hit `0`.
- Quintuple-family theorem data 57 is no longer the blocker; it is generated/loaded from current runtime artifacts with upstream quad55, triple53, and pair52 fallback hit `0`.
- Sextuple-family theorem data 57 is no longer the blocker; it is generated/loaded from current runtime artifacts with upstream quintuple57, quad55, triple53, and pair52 fallback hit `0`.
- Septuple/high-family remain the only imported lower-layer rows.

## decision

Do not spend the next round freshizing shell11/shell12 inventory-only rows. Keep them exposed as nonblocking perimeter rows and move the next freshization round to `septuple_family_expansion_theorem_data_57`.
