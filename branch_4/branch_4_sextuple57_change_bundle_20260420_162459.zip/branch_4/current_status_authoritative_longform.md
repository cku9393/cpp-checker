# 현재 상태 정리: lower-frontier freshization까지 반영한 authoritative 현황

## 1. 문서 목적

이 문서는 브랜치4의 메인 current-status longform이다.  
이번 기준점은 네 문장으로 요약된다.

- support8 proof slice는 현재 workspace에서 `support8_authoritative_completion_locked`까지 3-pass 기준으로 재현된다.
- current bundle metadata와 imported closed-output provenance는 계속 분리해서 읽어야 한다.
- top-level current verified theorem / audit item은 이제 모두 `fresh_current_runtime_generated`다.
- lower-frontier first-class inventory의 shell11/shell12 pair `4`개는 `keep_inventory_only_nonblocking`으로 확정했다.
- 남은 주요 caveat은 remaining `57` sublayers다. `pair_expansion_aggregate_52`, `triple_family_expansion_theorem_data_53`, `quadruple_family_expansion_theorem_data_55`, `quintuple_family_expansion_theorem_data_57`, `sextuple_family_expansion_theorem_data_57`는 current constructor/cache-backed path로 승격했다.

## 2. 현재 source of truth 구조

현재 authoritative 판단에서 먼저 보는 것은 문서가 아니라 코드와 runtime이다.

1. `branch_4/90/full_dynamic_top_tree_engine_90.cpp`
2. `branch_4/90/runtime/` 아래 current docs / artifacts / audit files
3. `branch_4/90/runtime/theorem_data_provenance_inventory_90.tsv`
4. `branch_4/90/runtime/provenance_audit_fingerprint_90.tsv`
5. `branch_4/90/runtime/lower_frontier_ladder_inventory_90.tsv`
6. `branch_4/90/runtime/support8_antecedent15_shell_theorem_generation_audit_90.tsv`
7. preserved `_90` notes

## 3. current workspace reproduction

### 3-1. code identity

- header says: `This is NOT the complete BOJ solver`
- non-`LOCAL_TEST` `main()`: dummy `return 0;`
- 현재 verified 성공의 의미: solver 완성 아님, support8 proof-system recovery 성공

### 3-2. compile / rerun

- release compile: verified
- LOCAL_TEST compile: verified
- pass1: `support8_authoritative_completion_locked`
- pass2: `support8_authoritative_completion_locked`
- pass3: `support8_authoritative_completion_locked`

### 3-3. docs / artifacts / audits

- required docs: `39 / 39`
- required artifacts: `8 / 8`
- artifact completion audit: verified
- document completion audit: verified
- rerun completion audit: verified
- audit freshness: verified
- current reproducible classification: `support8_authoritative_completion_locked`

## 4. current bundle metadata와 imported provenance의 분리

### current bundle metadata

- current bundle version: `90`
- current bundle source path: `branch_4/90/full_dynamic_top_tree_engine_90.cpp`
- current bundle summary path: `branch_4/90/project_status_summary_90.md`
- current runtime summary path: `branch_4/90/runtime/project_status_summary_90.md`

### imported closed-output provenance

- family-chain output `57`
- lower frontier ladder `67/69/70/71/72/74/75/76/77/79`
- archival shell15 frontier source `84`
- retained provenance path example: `/mnt/data/full_dynamic_top_tree_engine_84.cpp`

핵심은 이렇다.  
`90 current bundle`과 imported theorem-data provenance는 동시에 사실이지만 서로 다른 층이다.  
이번 라운드의 변화는 lower-frontier direct dependency subset까지 current constructor/cache path로 올라와 top-level mixed item이 사라졌고, family-chain lower layer 중 `pair_expansion_aggregate_52`, `triple_family_expansion_theorem_data_53`, `quadruple_family_expansion_theorem_data_55`, `quintuple_family_expansion_theorem_data_57`, `sextuple_family_expansion_theorem_data_57`도 current constructor/cache-backed path로 올라왔다는 점이다. Imported provenance catalog 자체가 삭제되었다는 뜻은 아니다.

## 5. provenance inventory 결과

### 5-1. top-level inventory

현재 machine-readable provenance inventory는 `19`개 item을 가진다.

- current verified: `16`
- archival claim: `3`
- fresh current runtime generated: `16`
- current runtime validated imported data: `0`
- mixed: `0`
- archival only: `3`

즉 top-level current verified theorem / audit item은 모두 fresh current-runtime generated다.

### 5-2. lower-frontier first-class inventory

별도 lower-frontier inventory는 `23`개 row를 가진다.

- direct shell-theorem dependency subset: `19`
- direct shell-theorem dependency freshized count: `19`
- inventory-only mixed rows outside the direct shell15 dependency subset: shell11/shell12 pair `4`

이 `4`개는 current top-level shell theorem을 막는 blocker가 아니라, first-class inventory transparency를 위해 분리해 둔 별도 row다.

이번 perimeter decision 결과:

- `freshize_now`: `0`
- `keep_inventory_only_nonblocking`: `4`
- `defer_after_family_chain`: `0`
- 다음 우선순위: family-chain lower imported layers

## 6. 현재 신뢰 가능한 결론

현재 신뢰 가능한 결론은 다음 다섯 줄이다.

1. support8 lock은 현재 workspace에서 3-pass 기준으로 current verified다.
2. exact-basis / basis-only theorem trio / family-chain top theorem objects / shell15 frontier pair / shell theorem / tail pattern / tail chain / completion lock은 current-generated 쪽으로 올라왔다.
3. current_runtime_validated_imported_data와 top-level mixed item은 모두 `0`이다.
4. lower-frontier inventory-only shell11/shell12 pair는 nonblocking perimeter row로 유지하고, family-chain lower layer 중 `pair_expansion_aggregate_52`, `triple_family_expansion_theorem_data_53`, `quadruple_family_expansion_theorem_data_55`, `quintuple_family_expansion_theorem_data_57`, `sextuple_family_expansion_theorem_data_57`는 fresh current-runtime generated로 승격했다.
5. 따라서 현재 단계는 “support8 slice reproducible and top-level freshized”이지, “every preserved lower theorem object in the broader archive freshly rederived”는 아니다.

## 6-1. pair-expansion aggregate 52 결과

`pair_expansion_aggregate_52`는 이번 라운드에서 imported lower layer caveat에서 current constructor/cache-backed provenance로 이동했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_pair_expansion_aggregate_52_from_bounded_region_scan_`
- pass2/pass3 cache loader: `load_current_pair_expansion_aggregate_52_runtime_artifact_`
- payload path: `branch_4/90/runtime/pair_expansion_aggregate_52_payload_90.tsv`
- region count: `28`
- raw / canonical / deduplicated candidates: `501 / 501 / 182`
- survivor counts: `0 / 0 / 0`
- payload fingerprint: `6003:2005080337376028436`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- fallback reachable / hit: `1 / 0`

## 6-2. triple-family theorem data 53 결과

`triple_family_expansion_theorem_data_53`은 이번 라운드에서 imported lower layer caveat에서 current constructor/cache-backed provenance로 이동했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_triple_family_expansion_theorem_data_53_from_pair52_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_triple_family_expansion_theorem_data_53_runtime_artifact_`
- payload path: `branch_4/90/runtime/triple_family_expansion_theorem_data_53_payload_90.tsv`
- region count: `35`
- raw / canonical / deduplicated candidates: `2110 / 2110 / 282`
- survivor counts: `0 / 0 / 0`
- payload fingerprint: `11888:3562593626991170520`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream pair52 fallback hit: `0`
- fallback reachable / hit: `1 / 0`

## 6-3. quadruple-family theorem data 55 결과

`quadruple_family_expansion_theorem_data_55`는 이번 라운드에서 imported lower layer caveat에서 current constructor/cache-backed provenance로 이동했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_quadruple_family_expansion_theorem_data_55_from_triple53_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_quadruple_family_expansion_theorem_data_55_runtime_artifact_`
- payload path: `branch_4/90/runtime/quadruple_family_expansion_theorem_data_55_payload_90.tsv`
- region count: `35`
- raw / canonical / deduplicated candidates: `3962 / 3962 / 294`
- survivor counts: `0 / 0 / 0`
- payload fingerprint: `15637:3406948456738223960`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- fallback reachable / hit: `1 / 0`

## 6-4. quintuple-family theorem data 57 결과

`quintuple_family_expansion_theorem_data_57`는 이번 라운드에서 imported lower layer caveat에서 current constructor/cache-backed provenance로 이동했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_quintuple_family_expansion_theorem_data_57_from_quad55_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_quintuple_family_expansion_theorem_data_57_runtime_artifact_`
- payload path: `branch_4/90/runtime/quintuple_family_expansion_theorem_data_57_payload_90.tsv`
- region count: `21`
- raw / canonical / deduplicated candidates: `3634 / 3634 / 294`
- survivor counts: `0 / 0 / 0`
- payload fingerprint: `11519:14985224666762482157`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream quad55 fallback hit: `0`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- fallback reachable / hit: `1 / 0`

## 6-5. sextuple-family theorem data 57 결과

`sextuple_family_expansion_theorem_data_57`는 이번 라운드에서 imported lower layer caveat에서 current constructor/cache-backed provenance로 이동했다.

- final provenance label: `fresh_current_runtime_generated`
- pass1 constructor: `build_current_sextuple_family_expansion_theorem_data_57_from_quintuple57_ready_family_scan_`
- pass2/pass3 cache loader: `load_current_sextuple_family_expansion_theorem_data_57_runtime_artifact_`
- payload path: `branch_4/90/runtime/sextuple_family_expansion_theorem_data_57_payload_90.tsv`
- region count: `7`
- raw / canonical / deduplicated candidates: `1632 / 1632 / 294`
- survivor counts: `0 / 0 / 0`
- payload fingerprint: `4567:5441664472856347648`
- imported equality result: `counts_and_consumer_visible_fingerprint_equal`
- upstream quintuple57 fallback hit: `0`
- upstream quad55 fallback hit: `0`
- upstream triple53 fallback hit: `0`
- upstream pair52 fallback hit: `0`
- fallback reachable / hit: `1 / 0`

## 7. 다음 액션

이제 가장 현실적인 다음 단계는 `septuple_family_expansion_theorem_data_57`를 current constructor/cache path로 올릴 수 있는지 확인하는 것이다. 그 다음에 high-family `57` 하위 계층을 다룬다.

이는 support8 lock recovery 이후의 provenance expansion 문제이지, 현재 support8 slice 복구 문제는 아니다.
