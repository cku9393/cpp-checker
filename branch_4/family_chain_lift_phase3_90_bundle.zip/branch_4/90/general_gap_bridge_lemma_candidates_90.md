# General Gap Bridge Lemma Candidates 90

## next candidate

First candidate after this round: `prove_support_reduction_operation_sublemma`.

The phase3 proof attempt is partially complete: layer projection payload preservation and canonical lift soundness are now proof-ready obligations. Counterexample-status preservation and operation-specific smaller-witness construction remain open. The next candidate is the support-reduction operation sublemma path.

Runtime candidates: `branch_4/90/runtime/general_gap_bridge_lemma_candidates_90.tsv`.
