# Higher-Support Escape Interface 90

## status after lift phase3

`higher_support_escape_interface_phase3_operation_open`.

The interface now distinguishes:

- recognized family-chain payload-preservation-open cases;
- phase2 layerwise refinement proof-open cases;
- phase3 projection/canonical proof-ready but not proved cases;
- smaller-witness operation-construction blockers;
- payload mismatch/canonicalization blockers;
- status-preservation blockers;
- support-reduction operation blockers;
- genuinely unrecognized/higher-support cases.

No support9+ scan is performed or implied.

Runtime interface: `branch_4/90/runtime/higher_support_escape_interface_90.tsv`.
