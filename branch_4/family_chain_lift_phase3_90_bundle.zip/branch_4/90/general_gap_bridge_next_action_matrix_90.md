# General Gap Bridge Next Action Matrix 90

## recommendation after lift phase3

Top recommendation: `prove_support_reduction_operation_sublemma`.

Second recommendation: `higher_support_necessity_recheck`.

Third recommendation: `limited_to_broader_generalization_plan`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `prove_support_reduction_operation_sublemma` | 84 | 90 | 76 | 74 | 90 | 89 | 1 | `prove_support_reduction_operation_sublemma` |
| `higher_support_necessity_recheck` | 73 | 84 | 58 | 64 | 88 | 81 | 2 | `higher_support_necessity_recheck` |
| `limited_to_broader_generalization_plan` | 68 | 80 | 55 | 60 | 82 | 73 | 3 | `limited_to_broader_generalization_plan` |
| `support_bound_completion` | 64 | 78 | 62 | 68 | 78 | 70 | 4 | `support_bound_completion` |
| `family_chain_lift_phase4_if_needed` | 61 | 78 | 70 | 75 | 75 | 68 | 5 | `family_chain_lift_phase4_if_needed` |
| `boj_problem_bridge_formalization` | 42 | 60 | 50 | 50 | 58 | 52 | 6 | `boj_problem_bridge_formalization` |

## rationale

Phase3 made layer projection payload preservation and canonical lift soundness proof-ready targets, but did not complete semantic preservation or counterexample-status preservation. The most concrete remaining blocker is operation-specific smaller-witness construction, so the sharp next target is `prove_support_reduction_operation_sublemma`.

This remains a bridge/planning state, not a full general theorem.
