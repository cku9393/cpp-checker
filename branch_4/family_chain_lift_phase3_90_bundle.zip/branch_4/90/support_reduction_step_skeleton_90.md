# Support Reduction Step Skeleton 90

## selected statement

`support_growth_partition`.

## status after lift phase3

`partition_ready_phase3_projection_canonical_ready_operation_open`.

The support `>8` branch now separates:

- reducible support operation cases;
- recognized family-chain cases with well-defined lifted payloads and phase3 projection/canonical proof-ready skeletons;
- payload preserved and absorbed cases conditional on status preservation;
- operation-specific smaller-witness-open cases;
- named higher-support or non-family-chain escape cases.

The support-reduction theorem is still not complete because counterexample-status preservation and operation-specific smaller-witness construction remain open.

Runtime skeleton: `branch_4/90/runtime/support_reduction_step_skeleton_90.tsv`.
