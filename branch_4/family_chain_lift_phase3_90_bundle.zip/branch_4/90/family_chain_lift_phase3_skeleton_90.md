# Family-Chain Lift Phase3 Skeleton 90

## lemma

`layer_projection_payload_preservation_and_canonical_lift_soundness`.

## exact statement

For recognized family-chain source-form witnesses, the phase3 target is restricted to layer projection payload preservation and canonical lift soundness. The current artifacts prove that projection layers are declared and well-defined under the recognized-source contract. They make layerwise semantic preservation and canonical lift commutation proof-ready, but do not prove them. Counterexample-status preservation and operation-specific smaller-witness construction remain separate blockers.

## selected target

- `phase3_needed_layer_projection_payload_preservation`
- `phase3_needed_canonical_lift_soundness`

## proof outline

1. Start from the phase2 source-target correspondence table.
2. Split the source payload by family-chain layer.
3. Check that every selected layer has a target projection row.
4. Isolate the layer-specific payload preservation sublemma for each layer.
5. Compare source canonicalization then lift with lift then target canonicalization.
6. Route canonical mismatch to canonical blocker, smaller-witness trigger, or named escape.
7. Leave counterexample-status preservation as a later semantic theorem.
8. Leave operation-specific smaller-witness construction to support-reduction operation proof.

## final status

`partial_phase3_projection_canonical_ready_operation_blocked`.

This is not a full family-chain lift proof and not a full general theorem.

Runtime skeleton: `branch_4/90/runtime/family_chain_lift_phase3_skeleton_90.tsv`.
