# General Gap Bridge Lemma Candidates 90

## purpose

These are lemma candidates, not proved theorem statements. They identify what can be derived from the current verified package and what still needs proof.

## status split

- `current_verified_derivable`: finite support8 closure lemma, archive independence lemma.
- `proof_ready_skeleton`: minimal counterexample reduction under the selected limited support8 statement.
- `candidate_needs_proof`: tail monotonicity, family-chain lift, frontier ladder completeness.
- `candidate_needs_shell16`: shell15/tail absorption through shell16 boundary.
- `candidate_needs_higher_support_bound`: support8 sufficiency/support bound.
- `candidate_needs_solver_constructivity`: BOJ constructive bridge.

## next lemma target

The first lemma to attempt next is `tail_monotonicity_candidate`. The `minimal_counterexample_reduction_candidate` now has a selected statement, measure, normal-form contract, obligation split, escape interface, and limited proof-ready skeleton; it is not a completed full-general proof.
