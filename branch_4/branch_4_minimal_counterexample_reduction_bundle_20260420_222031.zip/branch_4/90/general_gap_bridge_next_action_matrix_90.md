# General Gap Bridge Next Action Matrix 90

## recommendation

Top recommendation: `tail_monotonicity_bridge`.

Second recommendation: `shell16_preflight_refactor`.

Third recommendation: `limited_bridge_theorem_proof_attempt`.

## scoring

| action | readiness | proof value | engineering cost | risk | dependency clarity | expected progress | order | final recommendation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `tail_monotonicity_bridge` | 72 | 88 | 50 | 55 | 82 | 88 | 1 | `tail_monotonicity_bridge` |
| `shell16_preflight_refactor` | 64 | 78 | 70 | 60 | 70 | 80 | 2 | `shell16_preflight_refactor` |
| `limited_bridge_theorem_proof_attempt` | 62 | 90 | 65 | 70 | 68 | 76 | 3 | `limited_bridge_theorem_proof_attempt` |
| `frontier_ladder_completeness_bridge` | 66 | 78 | 55 | 50 | 68 | 72 | 4 | `frontier_ladder_completeness_bridge` |
| `family_chain_lift_bridge` | 72 | 74 | 45 | 45 | 75 | 70 | 5 | `family_chain_lift_bridge` |
| `formalize_support_bound_lemma` | 40 | 90 | 80 | 80 | 40 | 68 | 6 | `formalize_support_bound_lemma` |
| `prove_minimal_counterexample_reduction` | 55 | 95 | 55 | 65 | 85 | 66 | 7 | `proof_ready_skeleton_done` |
| `boj_problem_bridge_formalization` | 58 | 65 | 50 | 50 | 60 | 62 | 8 | `boj_problem_bridge_formalization` |

## rationale

`minimal_counterexample_reduction` now has a selected limited statement, well-founded measure, witness normal form, obligation split, sublemma proof table, and escape interface. Its first open escape is `tail_monotonicity_or_tail_absorption`, so `tail_monotonicity_bridge` is now first. `shell16_preflight_refactor` is second because shell16 should only be opened after the tail bridge clarifies whether the first boundary escape is real. `limited_bridge_theorem_proof_attempt` is third because it should wait until the tail escape is closed or explicitly assumed.
