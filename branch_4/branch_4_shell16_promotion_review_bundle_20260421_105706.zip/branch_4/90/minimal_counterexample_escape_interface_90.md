# Minimal Counterexample Escape Interface 90

## purpose

This interface fixes where a minimal witness goes if it cannot be captured by the current finite package.

## escape classes

- `none_current_scope`: captured by the current finite package; contradiction uses support8 closure.
- `tail_monotonicity_escape`: checked tail witness is closed by the tail bridge; the first shell16 boundary was reviewed with local exact / plus-one / theorem-preserving survivors `2 / 0 / 0`. The local exact pair is visible but nonblocking for the current theorem-preserving escape.
- `shell16_escape`: witness crosses the shell15/current-tail boundary or the first unchecked tail-extension boundary and now routes to `limited_bridge_theorem_proof_attempt`; the current reviewed result is `shell16_probe_completed_local_exact_survivors_present_no_theorem_preserving_survivors`.
- `higher_support_escape`: witness cannot be reduced to support<=8 and requires a support-bound lemma.
- `boj_constructivity_escape`: theorem-to-solver constructivity is required, but not for the mathematical bridge.
- `archive_independence_escape`: archival-only note confusion; already handled by provenance separation.

## next blocker

The next blocker for the reduction skeleton is `limited_bridge_theorem_proof_attempt`.
