# General Gap Bridge Lemma Candidates 90

## shell16 attempt update

The shell/tail absorption candidate and minimal-counterexample reduction candidate now have a non-promoting shell16 attempt result. Their missing input is no longer the attempt itself; it is promotion review for the shell16 result or an alternative absorption-step proof.

## purpose

These are lemma candidates, not proved theorem statements. They identify what can be derived from the current verified package and what still needs proof.

## status split

- `current_verified_derivable`: finite support8 closure lemma, archive independence lemma.
- `proof_ready_skeleton`: minimal counterexample reduction under the selected limited support8 statement; tail monotonicity bridge under checked-tail absorption plus shell16 attempt result.
- `candidate_needs_proof`: tail monotonicity, family-chain lift, frontier ladder completeness.
- `current_verified_limited_bridge_lemma`: shell15/tail first-boundary review through the attempted shell16 boundary after no-promotion result.
- `candidate_needs_higher_support_bound`: support8 sufficiency/support bound.
- `candidate_needs_solver_constructivity`: BOJ constructive bridge.

## next lemma target

The first action to attempt next is `limited_bridge_theorem_proof_attempt`. The `tail_monotonicity_candidate` now proves checked-tail capture under current scope and has reviewed first shell16 boundary facts, but it is not full tail monotonicity.
