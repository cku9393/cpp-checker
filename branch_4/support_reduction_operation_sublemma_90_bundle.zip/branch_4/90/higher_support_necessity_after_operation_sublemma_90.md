# Higher-Support Necessity After Operation Sublemma 90

## result

Higher-support recheck remains deferred. The selected operation `delete_redundant_support_coordinate` now has a first-class proof-ready skeleton with measure decrease and conditional counterexample transfer under the redundancy precondition. This does not close all operation-specific smaller-witness cases.

## decision

Next target:

`prove_next_support_reduction_operation_sublemma`

Reason: `project_to_active_support`, coordinate contraction, canonical motif compression, and family-chain absorption reduction still need operation-specific proofs before a higher-support scan would be informative.

Runtime table: `branch_4/90/runtime/higher_support_necessity_after_operation_sublemma_90.tsv`.
