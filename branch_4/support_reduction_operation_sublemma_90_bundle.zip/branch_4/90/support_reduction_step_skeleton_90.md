# Support Reduction Step Skeleton 90

## selected statement

`support_growth_partition`.

## status after selected operation proof attempt

`partition_ready_selected_delete_redundant_operation_ready_remaining_operations_open`.

The support `>8` branch now separates:

- selected redundant-coordinate deletion case with support-size decrease proved under precondition;
- other reducible support operation cases still open;
- recognized family-chain cases with well-defined lifted payloads and phase3 projection/canonical proof-ready skeletons;
- payload preserved and absorbed cases conditional on status preservation;
- operation-specific smaller-witness-open cases;
- named higher-support or non-family-chain escape cases.

The support-reduction theorem is still not complete because this proves only one selected operation under a redundancy precondition. Active-support projection, coordinate contraction, canonical motif compression, family-chain absorption reduction, and arbitrary operation selection remain open.

Runtime skeleton: `branch_4/90/runtime/support_reduction_step_skeleton_90.tsv`.
