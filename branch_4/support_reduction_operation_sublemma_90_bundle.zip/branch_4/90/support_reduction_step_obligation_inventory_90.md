# Support Reduction Step Obligation Inventory 90

## updated after selected operation proof attempt

The selected operation `delete_redundant_support_coordinate` now has a first-class proof-ready skeleton. Measure decrease and counterexample transfer are proved under the redundancy precondition. The support-reduction step remains incomplete because other operations and arbitrary-witness operation selection are still open.

Runtime inventory: `branch_4/90/runtime/support_reduction_step_obligation_inventory_90.tsv`.
