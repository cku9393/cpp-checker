# Family-Chain Operation-Specific Smaller Witness 90

## purpose

This document connects the smaller-witness branch to existing support-reduction operations.

## result

No new operation is introduced. The selected `delete_redundant_support_coordinate` operation now has a proof-ready skeleton with support-size decrease and conditional counterexample transfer under the redundancy precondition. Remaining smaller-witness branches are still operation-specific and should be handled by `prove_next_support_reduction_operation_sublemma` next.

Runtime table: `branch_4/90/runtime/family_chain_operation_specific_smaller_witness_90.tsv`.
