# Support Reduction Sublemma Proofs 90

## updated after selected operation proof attempt

The selected operation `delete_redundant_support_coordinate` now supplies a smaller-witness proof-ready skeleton with support-size decrease proved under the redundancy precondition. Other support-reduction operations remain separate next-action candidates.

Runtime table: `branch_4/90/runtime/support_reduction_sublemma_proofs_90.tsv`.
